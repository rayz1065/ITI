/* $Id$ */

/*

"Quadrati magici" (IOI 1996)
Copyright (C) 2000 Massimo Santini

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <search.h>

#include "queue.h"

#define CONFLEN 8

#include "auto.c"

/* procedura di confronto, per la ricerca */
int cmpconf( const void *k, const void *c )
{
	return strncmp( (char *)k, *(char **)c, CONFLEN );
}

/* dalla configurazione alla posizione */
int conf2pos( char *c )
{
	return ((char **)bsearch( c, pos2conf, CONFNUM, sizeof( pos2conf[0] ), cmpconf ) 
			- (char **)pos2conf);
}

int main( int argc, char **argv )
{
	int v[CONFNUM], p, q, t, i, l;

	if ( argc != 2 ) {
		fprintf( stderr, "%s: invocare con la configurazione cercata\n", argv[0] );
		exit( EXIT_FAILURE );
	}
	t = conf2pos( argv[1] );
	if ( t < 0 || t >= CONFNUM ) {
		fprintf( stderr, "la configurazione indicata non � raggiungibile\n" );
		exit( EXIT_FAILURE );
	}

	/* calcolo del cammino minimo, tramite visita in ampiezza */

	for ( i = 0; i < CONFNUM; i++ ) v[i] = -1;
	qinit();

	p = 0;
	put( p );

	while ( !qempty() && p != t ) {
		p = get();
		for ( i = 0; i < 3; i++ ) {
			q = adj[p][i];
			if ( v[q] == -1 ) {
				v[q] = p;
				put( q );
			}
		}
	}

	/* dal cammino alla sequenza di trasformazioni */

	l = 0;
	while ( p != 0 ) {
		q = v[p];
		if ( adj[q][0] == p ) { l++; printf( "A\n" ); }
		else if ( adj[q][1] == p ) { l++; printf( "B\n" ); }
		else if ( adj[q][2] == p ) { l++; printf( "C\n" ); }
		p = q;
	}
	printf( "%d\n", l );

	/* si osservi che l'output viene prodotto in ordine inverso a
	  quello richiesto, ma � immediato inveritrlo... */

	return 0;
}

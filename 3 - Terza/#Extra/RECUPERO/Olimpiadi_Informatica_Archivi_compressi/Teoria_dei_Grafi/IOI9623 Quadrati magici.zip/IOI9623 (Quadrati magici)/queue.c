/* $Id$ */

/*

"Quadrati magici" (IOI 1996)
Copyright (C) 2000 Massimo Santini

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "queue.h"

#define MAXQUEUE 10000

static int queue[MAXQUEUE + 1], head, tail;

void qinit( void )
{
	head = tail = 0;
}

void put( int v )
{
	queue[tail++] = v;
	if ( tail > MAXQUEUE ) tail = 0;
}

int get( void )
{
	int t = queue[head++];
	if ( head > MAXQUEUE ) head = 0;
	return t;
}

int qempty( void )
{
	return head == tail;
}

/* camelot *
   solutore
   Roberto Grossi  2005-02-26
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#define STDSTREAM
//#define DEBUG

#define  MaxN   2000

char A[MaxN][MaxN];           // Matrice di adiacenza/amicizia
char mark[MaxN];  // Marca i nodi nel ciclo/cammino corrente
int N;            // I nomi dei vertici sono 0, 1, ..., N-1

int L[2][MaxN];  // Ciclo/cammino in costruzione (lista bidirezionale)
int start, end;


int diff( int j, int i ){  // restituisce l'indice 0/1 del puntatore in L[][j] != i
  assert( L[0][j] != i || L[1][j] != i );
  if ( L[0][j] != i )
    return 0;
  else
    return 1;
}

int same( int j, int i ){  // restituisce l'indice 0/1 del puntatore in L[][j] == i
  assert( L[0][j] == i || L[1][j] == i );
  if ( L[0][j] == i )
    return 0;
  else
    return 1;
}


int next_unmarked( int i ){
  int j;
  for (j=0; j<N; j++)
    if ( (!mark[j]) && A[i][j] )
      return j;
  return -1;
}

int choose_unmarked( int *x ){
  int i, j;
  for (i=0; i<N; i++)
    if (mark[i]) {
      j = next_unmarked( i );
      *x = i;
      if ( j >= 0 ) return j;
    }
  return -1;
}



int test[MaxN]; 


int main(int argc, char *argv[]) {
  int i, j, k, x, count;
  FILE *in, *out;

#ifdef STDSTREAM
  in = stdin;
  out = stdout;
#else
  in = fopen("input.txt", "r");
  out = fopen("output.txt", "w");
#endif

  if ( in == NULL || out == NULL )
    return 1;
  
  if ( fscanf(in, "%d", &N) != 1 )
    return 1;
  assert( 1 < N && N < MaxN );

  /* Lettura input */

  for ( i = 0 ; i < N ; i++ )
    for ( j = 0 ; j < N ; j++ ) {
      if ( fscanf(in, "%d", &x ) != 1 )
	return 1;
      A[i][j] = x; 
      assert ( A[i][j] == 0 || A[i][j] == 1 ); 
    }

#ifdef DEBUG
  printf("%d\n", N);
  for ( i = 0 ; i < N ; i++ ){
    printf("%d", A[i][0]);
    for (j=1; j < N; j++)
      printf(" %d", A[i][j]);
    printf("\n");
  }
  printf("\n");
#endif

  /* Risoluzione */

  for (i=0; i < N; i++) {
    L[0][i] = L[1][i] = i;
    mark[i] = 0;
  }

  // Partiamo dal nodo 0 
  mark[0] = 1;
  start = end = 0;
  count = 1;

  // Creiamo un cammino massimale, dove L[0][] = pred[] e L[1][] = succ[]
  i = next_unmarked( end );
  while ( i >= 0 ) {
    count++;
    mark[i] = 1;    // Appendilo in fondo al cammino
    L[1][end] = i; 
    L[0][i] = end;
    end = i;
    i = next_unmarked( end );
  }

#ifdef DEBUG
  printf("count = %d\n", count);

  printf("L[0]: ");
  for (i=0; i<N; i++)
    printf(" %d", L[0][i] );
  printf("\nL[1]: ");
  for (i=0; i<N; i++)
    printf(" %d", L[1][i] );
  printf("\n");
  printf("\n");

  i = j = 0; x = count;
  printf("1");
  while ( --count > 0 ){
    k = diff(j,i);
    i = j;
    j = L[k][i];
    printf(" %d", j+1);
  }
  printf("\n");
  count = x;

  printf("count %d start %d end %d A[][] %d\n", count, start+1, end+1, A[start][end]);

#endif

    if ( count == N && A[start][end] == 1 ){
      fprintf(stderr, "greedy: eureka!\n");
  //    return 0;
    }
  
  // Lo trasformiamo in un ciclo: -(i,j) +(start,j) +(i,end)
  i = start;
  j = L[1][i];
  while ( ! (A[start][j] && A[i][end]) ){
    i = j;
    j = L[1][i];
    assert( j != end );
  }
  L[1][i] = end;   // A causa di queste operazioni, succ e pred sono relativi...
  L[1][end] = i;
  L[0][j] = start;
  L[0][start] = j;
  end = j;

  // Estendiamo il ciclo con un nodo alla volta
  while ( count < N ) {
    x = choose_unmarked( &j ); // Collegato a un qualunque nodo marcato j
    assert( x >= 0 );
    mark[x] = 1;    
    count++;
    // Spezza il ciclo ed estendilo con x: -(i,j), start=i, +(j,x), end=x
    i = L[0][j];
    k = same( i,j );
    L[k][i] = i;
    start = i;
    L[0][j] = x;
    L[0][x] = j;
    end = x;

    // Lo trasformiamo in un ciclo: -(i,j) +(start,j) +(i,end)
    i = start;
    j = L[diff(i,i)][i];
    while ( ! (A[start][j] && A[i][end]) ){
      k = diff(j,i);
      i = j;
      j = L[k][i];
      assert( j != end );
    }
    k = same( i,j );
    L[k][i] = end;   // A causa di queste operazioni, succ e pred sono relativi...
    k = same( end, end);
    L[k][end] = i;
    k = same( j,i );
    L[k][j] = start;
    k = same( start, start );
    L[k][start] = j;
    end = j;
  }


  // Stampa su stdin e verifica la soluzione su stderr

  for (i=0; i<N; i++)
    mark[i] = 0;

  i = j = 0;
  mark[0] = 1;
  test[0]=x=0;
  printf("1");
  while ( --count > 0 ){
    k = diff(j,i);
    i = j;
    j = L[k][i];
    test[x++] = j;
    if (mark[j]){
      fprintf(stderr, "\nKO\n");
      return 0;
    }
    mark[j] = 1;
    printf(" %d", j+1);
  }
  printf("\n");


  // verifica di test


  if (!A[test[0]][test[N-1]]){
    fprintf(stderr, "\nKO\n");
    return 0;
  }
  for (i = 1; i < N; i++)
    if (!A[test[i-1]][test[i]]){
      fprintf(stderr, "\nKO\n");
      return 0;
    }
  fprintf(stderr, "\nOK\n");
      

  return 0;
}

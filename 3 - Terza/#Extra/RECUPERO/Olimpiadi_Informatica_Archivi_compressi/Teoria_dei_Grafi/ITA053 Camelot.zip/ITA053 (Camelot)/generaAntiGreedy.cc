/*
Copyright (C) 2005 Romeo Rizzi

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/* Da chiamare con
   ./generatore N seed

   dove N e` il numero dei cavalieri e seed e` il seme casuale
*/


#include <iostream>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

const int MAX_N = 2000;

int main(int argN, char* argV[])
{
  if (argN<2) {
    cerr << "Troppi pochi parametri." << endl;
    cerr << "Obbligatorio N = numero cavalieri" << endl;
    cerr << "Opzionale SEME per randomness" << endl;
    exit(1);	
  }

  int n=atoi(argV[1]);

  if (argN==2) srand(time(NULL)); 
  else {
      int seed=atoi(argV[2]);
      srand(seed);
  }

  int Mcabled[n][n];
  for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
        if(i==j) Mcabled[i][j] = 0;
        else Mcabled[i][j] = 1;
  for(int i=0;i<n/2;i++)
     for(int j=0;j<n/2;j++)
        Mcabled[i][j] = 0;

  int perm[n]; int tmpSwap; int randPos; 
  for(int i=0;i<n;i++) perm[i] = i; 
  for(int i=n-1;i;i--) {
    randPos = rand() % i+1;
    tmpSwap = perm[i];
    perm[i] = perm[randPos];
    perm[randPos] = tmpSwap;
  }

  int M[n][n];
  for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
        M[i][j] = Mcabled[perm[i]][perm[j]];

  cout << n << endl;
  for(int i=0;i<n;i++) {
     for(int j=0;j<n;j++) {
        cout << M[i][j] << " ";
     }
     cout << endl;
  }

  return 0;
}

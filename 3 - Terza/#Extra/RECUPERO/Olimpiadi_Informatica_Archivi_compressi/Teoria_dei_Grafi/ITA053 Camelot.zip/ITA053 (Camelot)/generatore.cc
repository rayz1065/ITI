/*
Copyright (C) 2005 Romeo Rizzi

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/* Da chiamare con
   ./generatore N seed

   dove N e` il numero dei cavalieri e seed e` il seme casuale
*/


#include <iostream>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

const int MAX_N = 2000;

int main(int argN, char* argV[])
{
  if (argN<2) {
    cerr << "Troppi pochi parametri." << endl;
    cerr << "Obbligatorio N = numero cavalieri" << endl;
    cerr << "Opzionale SEME per randomness" << endl;
    exit(1);	
  }

  int n=atoi(argV[1]);

  if (argN==2) srand(time(NULL)); 
  else {
      int seed=atoi(argV[2]);
      srand(seed);
  }

  int M[n][n];
  int deg[n];
  for(int i=0;i<n;i++) {
     for(int j=0;j<n;j++)
        if(i==j) M[i][j] = 0;
        else M[i][j] = 1;
     deg[i] = n-1;
  }

  int nodeA[n*n];
  int nodeB[n*n];
  int numRemovableEdges = 0;
  if(n>3) {
    for(int i=0;i<n;i++) {
       for(int j=i+1;j<n;j++) {
          nodeA[numRemovableEdges] = i;
          nodeB[numRemovableEdges] = j;
          numRemovableEdges++;
       }
    }
  }

  while (numRemovableEdges) {
    int choosen = rand() % numRemovableEdges;

    if ((nodeA[choosen] >= n) || (nodeB[choosen] >= n)) {
      cerr << "Stiamo eliminando arco: (" << nodeA[choosen]-1 << ","
           << nodeB[choosen]-1 << "). Quando n = " << n << endl;
      exit(1);	
    }

    M[nodeA[choosen]][nodeB[choosen]] = 0;
    M[nodeB[choosen]][nodeA[choosen]] = 0;
    deg[nodeA[choosen]]--; deg[nodeB[choosen]]--;

    numRemovableEdges--;
    for(int i=choosen;i<numRemovableEdges;i++) {
       nodeA[i] = nodeA[i+1];
       nodeB[i] = nodeB[i+1];
    }
    int pos = 0;
    for(int i=0;i<numRemovableEdges;i++) {
      if((deg[nodeA[i]] > n/2 +(n%2)) && (deg[nodeB[i]] > n/2 +(n%2))) {
        nodeA[pos] = nodeA[i];
        nodeB[pos] = nodeB[i];
        pos++;
      }
    }
    numRemovableEdges = pos;
  };
  
  cout << n << endl;
  for(int i=0;i<n;i++) {
     for(int j=0;j<n;j++) {
        cout << M[i][j] << " ";
     }
     cout << endl;
  }

  return 0;
}

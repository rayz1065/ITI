/*
Copyright (C) 2005 Romeo Rizzi

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


da utilizzare passando gli output su tr -s " "

*/


#include <iostream>
#include <fstream>
#include <string>
#include <set>
//#define DEBUG

using namespace std;

const int MAX_N = 2000; // maximum number of nodes.

int M[MAX_N][MAX_N];
int path[MAX_N];
int notepadPath[MAX_N];
int taken[MAX_N];
int numTaken;


void Invert() {
  for(int i=0;i<numTaken;i++) notepadPath[i] = path[i];
  int j=numTaken-1;
  for(int i=0; i<numTaken; i++,j--)
     path[i] = notepadPath[j];
}

int Grow(int numNodes) {
  for(int i=0;i<numNodes;i++)
    if((taken[i] == 0) && (M[i][path[numTaken-1]])) {
      path[numTaken] = i;
      taken[i] = 1;
      numTaken++;
      return 1;
    }
  return 0;
}

void CloseCycle() {
  int pos = 0;
  while ( (M[path[pos]][path[numTaken-1]] == 0) ||
          (M[path[pos+1]][path[0]] == 0) ) pos++;


  for(int i=pos+1;i<numTaken;i++) notepadPath[i] = path[i];

  int j=numTaken-1;
  for(int i=pos+1; i<numTaken; i++,j--)
     path[i] = notepadPath[j];

}


int main(int argc, char* argv[])
{
  ifstream inputFile(argv[1]);
  ifstream answerFile(argv[2]);

  int n;
  inputFile>>n;

  for(int i=0;i<n;i++) {
     for(int j=0;j<n;j++) {
        inputFile>>M[i][j];
        //cout << M[i][j] << " ";
     }
     //cout << endl;
  }

  for(int i=0;i<n;i++) taken[i] = 0;

  path[0] = 0;
  taken[0] = 1;
  numTaken = 1;

  do {} while (Grow(n));
  Invert();
  do {} while (Grow(n));
  CloseCycle();

  while (numTaken < n) {
    int outsider = n-1;
    while (taken[outsider]) outsider--;
    int inside = numTaken - 1;
    while (M[outsider][path[inside]] == 0) inside--;

    // begin: elaborare su notepadPath il cammino che parte da outsider
    for(int i=0;i<numTaken;i++) notepadPath[i] = path[i];
    
    int j=0;
    for(int i=inside+1; j<numTaken; i++,j++)
       path[j] = notepadPath[i%numTaken];
       
    path[numTaken] = outsider;
    numTaken++;
    taken[outsider]=1;
    // end: elaborare su notepadPath il cammino che parte da outsider


    do {} while (Grow(n));

    CloseCycle();
  }

  // begin: output del ciclo Hamiltoniano contenuto in path
  //        partendo dal cavaliere di nome 0 (rinominato in 1).

  int pos = 0;
  while (path[pos] !=0) pos++;

  do {
    cout << path[pos]+1 << " ";
    pos++;
  } while(pos < n);
  pos = 0;
  while (path[pos] !=0) {
    cout << path[pos]+1 << " ";
    pos++;
  }
  cout << endl;
  // end: output del ciclo Hamiltoniano contenuto in path
  //      partendo dal cavaliere di nome 0 (rinominato in 1).

  exit(0);
}


/*      

Condominio (selezioni nazionali 2002)

Copyright (C) 2002 Sebastiano Vigna 

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.
	
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.
	
You should have received a copy of the GNU General Public License along
with this program; see the file COPYING.  If not, write to the Free
Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.  


Questa soluzione � una semplice enumerazione di tutti i cammini che li stampa
quando sono cicli. Abbiamo per� l'accortezza, partendo dal nodo s, di passare
solo per nodi di indice maggiore di s. In questo modo evitiamo di emettere due
volte lo stesso ciclo, o lo stesso ciclo in ordine diverso.

*/

#include <stdio.h>
#include <string.h>

#define MAXN 1000

int N, M;

char G[MAXN][MAXN];
char b[MAXN];

int B[MAXN][MAXN]; /* Per ogni nodo v, la lista di nodi che vanno sbloccati
							 quando v viene sbloccato. */
int lB[MAXN];		 /* La lunghezza di ciascuna lista. */

int A[MAXN];		/* Lista dei nodi della componente connessa corrente */
int n;				/* Dimensione della componente connessa corrente. */
int s;				/* Minimo vertice corrente nella costruzione dei cammini. */

int pila[MAXN], l; /* La pila di nodi corrente. */




#define min( a, b )    ( (a) < (b) ? (a) : (b) )

int vis[MAXN]; /* Nodo visitato. */
int tot;

int visita( int v ) {
	int i, w;

	vis[v] = 1;
	pila[l++] = v;
	
	for ( w = s; w < N; w++ ) 
		if (G[v][w]) {
			if ( w == s ) {
				for(i=0; i<l; i++) printf("%s%d", i ? " " : "", pila[i]+1);
				printf("\n");
				tot++;
			}
			else if (!vis[w]) visita(w);
		}

	vis[v] = 0;
	l--;
}

int main() {
	FILE *f;
	int i, j, k;
	
	f=stdin;
	fscanf(f,"%d",&N);
	fscanf(f,"%d",&M);
	for (i=0; i<M; i++) {
		fscanf(f,"%d %d",&j,&k);
		G[j-1][k-1]=1;
	}
	
	for(s=0; s<N; s++) visita(s);

	//fprintf(stderr, "TOTALE: %d\n", tot);
}

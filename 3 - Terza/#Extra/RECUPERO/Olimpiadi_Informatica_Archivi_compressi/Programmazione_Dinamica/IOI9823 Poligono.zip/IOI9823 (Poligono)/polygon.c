/*

Polygon (IOI 1998)
Copyright (C) 2000 Sebastiano Vigna

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA




Utilizziamo la programmazione dinamica per calcolare i massimi e minimi valori
ottenibili con una sottoespressione che coinvolge i vertici a partire dal
vertice j. Per fare cio` basta utilizzare i valori estremali delle possibili
coppie di sottoespressioni di lunghezza k e i-k che partono dal vertice
j e dal vertice j+k, rispettivamente.

E` necessario calcolare i massimi e i minimi perche' per massimizzare un
prodotto bisogna considerare il caso che un fattore sia negativo.

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <limits.h>

#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))

#define MAXN 50     /* Massimo numero di vertici. */

char op[MAXN];     /* Operatore che compare _prima_ del vertice corrispondente. */
int n[MAXN];       /* Intero sul vertice */
long massval[MAXN][MAXN]; /*	Matrice da riempire dinamicamente: il primo
										indice e` la lunghezza della sottoespressione da
										massimizzare, il secondo il vertice da cui parte
										l'espressione. */

long minval[MAXN][MAXN]; /* Come sopra per i minimi. */

int tempn[MAXN];
char tempop[MAXN];       /* In queste matrici ricopieremo op e n a meno del
									primo lato eliminato e di rotazioni cicliche. */
long M[MAXN];            /* Massimo ottenibile rimuovendo inizialmente un
									certo lato. */


int main(int argc, char *argv[]) {

	int i, j, k, l, N;
	char *t;
	long p = 0, tmax, tmin, ottimo;

	scanf("%d\n", &N);

	for(i=0; i<N; i++) {
		scanf("%c %d \n", &op[i], &n[i]);
		op[i] = op[i] == 't' ? '+' : '*'; /* Usiamo una notazione piu` umana. */
	}

	ottimo = INT_MIN; /* Si parte da -oo */

	for(l=0; l<N; l++) { /* l e` il lato da eliminare */

		for(i=0; i<N; i++) {/* Ricopiamo n in tempn e op in tempop a partire da
									  l ciclicamente fino a l-1. */
			tempn[i] = n[(i+l) % N];
			tempop[i] = op[(i+l) % N];
		}

		/* I valori massimi e minimi per le sottoespressioni di lunghezza 1 sono
			gli elementi di tempn. */

		for(i=0; i<N; i++) massval[1][i] = minval[1][i] = tempn[i];

		for(i=2; i<=N; i++) { /* i scorre la dimensione corrente di una sottoespressione. */
			for(j=0; j<=N-i; j++) { /* j scorre la posizione da cui calcoliamo i
											valori estremali di una sottoespressione di
											lunghezza i. */
				tmax = INT_MIN;
				tmin = INT_MAX;
				for(k=1; k<i; k++) { /* k scorre gli spezzamenti possibili per
												un'espressione lunga j.*/
					if (tempop[j+k] == '+') {
						tmax = max(tmax, massval[k][j] + massval[i-k][j+k]);
						tmin = min(tmin, minval[k][j] + minval[i-k][j+k]);
					}
					else { /* Massimizzare e minizzare un prodotto e` solo un po'
								piu` complicato che farlo per una somma! */
						tmax = max(tmax,
									 max(massval[k][j] * massval[i-k][j+k],
										  max(massval[k][j] * minval[i-k][j+k],
												max(minval[k][j] * massval[i-k][j+k],
													 minval[k][j] * minval[i-k][j+k]))));
						tmin = min(tmin,
									 min(massval[k][j] * massval[i-k][j+k],
										  min(massval[k][j] * minval[i-k][j+k],
												min(minval[k][j] * massval[i-k][j+k],
													 minval[k][j] * minval[i-k][j+k]))));
					}
				}

				/* A questo punto tmax e tmin contengono il massimo e il minimo
					valore ottenibile con una sottoespressione di lunghezza i
					costruita a partire dal vertice j. */

				massval[i][j] = tmax;
				minval[i][j] = tmin;
			}
		}

		/* massval[N][0] ora contiene il massimo valore di un'espressione di
			lunghezza N ottenuta a partire da 0, cioe` il massimo valore di
			un'espressione che utilizza tutti i vertici. Dobbiamo pero`
			massimizzare anche rispetto alla scelta di l. */

		M[l] = massval[N][0];
		ottimo = max(ottimo, M[l]);
	}


	printf("%d\n", ottimo);

	/* Stampiamo ora i valori di i per cui la cancellazione dell'i-esimo lato ha
	dato origine a un risultato ottimo. ATTENZIONE: l'indicizzazione e` da uno!
	t e` un trucchetto per separare i numeri con uno spazio. */
	for(t=NULL, i=0; i<N; i++)
		if (M[i] == ottimo) printf("%s%d", t ? " " : (t = ""), i+1);

	printf("\n");
}

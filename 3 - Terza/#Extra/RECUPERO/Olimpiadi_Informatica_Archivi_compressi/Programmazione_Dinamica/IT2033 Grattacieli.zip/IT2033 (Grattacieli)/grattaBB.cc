/*

Grattacieli, (seconda selezione nazionale OII 2003)
Soluzione con algoritmo di Back-tracking e Branch&Bound

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

const int MAX_N = 1000;
const int MAX_K = 400;

int inc[MAX_N], sol[MAX_K], tmp[MAX_K];
int sMax,N,K;

void savesol()
{
  sol[0]=tmp[0];
  for(int i=1;i<K-1;i++)
    sol[i]=tmp[i]-tmp[i-1];
  sol[K-1]=N-tmp[K-2]-1;
}

void paint(int col,int prevMax)
{
  if (prevMax>sMax) return;
  if (col==K-1) 
    {
      if (inc[N-1]-inc[tmp[K-2]]>prevMax)
	{prevMax=inc[N-1]-inc[tmp[K-2]];}
      if (sMax>prevMax) 
	{
	  sMax=prevMax;
	  savesol(); 
	}
      return;
    }
  for(tmp[col]=col?tmp[col-1]+1:0;tmp[col]<=N-K+col;tmp[col]++)
    paint(col+1,(inc[tmp[col]]-(col?inc[tmp[col-1]]:0)>prevMax)?(inc[tmp[col]]-(col?inc[tmp[col-1]]:0)):prevMax );
}


int main()
{
  ifstream fin("input.txt");
  ofstream fout("output.txt");

  int i,j,k,a,p;

  fin>>N>>K;
  fin>>inc[0];
  for(i=1;i<N;i++)
    {
      fin>>a;
      inc[i]=inc[i-1]+a;
    }
  
  sMax=INT_MAX;

  paint(0,0);

  fout<<sMax<<endl;
  for(i=0;i<=sol[0];i++) fout<<1<<' ';
  for(i=1;i<K;i++)
    {
      for(j=0;j<sol[i];j++)
	fout<<i+1<<' ';
    }
  fout<<endl;

  fout.close();

}

#include <fstream>
#include <iostream>
#include <cmath>
using namespace std;

const int MAX_N=1000;
const int MAX_K=400;

int col[MAX_K+1], v[MAX_N];

void ex( char *msg, float res ) {
   if (msg) cerr << "[\x1b[1m\x1b[31m" << msg << "\x1b[m] ";
   cout << res << endl;
   exit(0);
}

int main(int argc, char* argv[])
{
  ifstream fin(argv[1]);
  ifstream rout(argv[2]);
  ifstream gout(argv[3]);

  int N,K,gval,rval;

  if (argc!=4) 
    {
      cerr<<"correttore input output di riferimento output dato"<<endl;
      return 0;
    }

  fin >> N >> K;
  rout>>rval;
  gout>>gval;

  if (rval<gval) ex( "La soluzione data � maggiore dell'ottimo", 0 );
  if (rval>gval) ex( "La soluzione data � minore dell'ottimo", 0 );

  int pre=0,a, sum;

  for(int i=0;i<N;i++)
      fin>>v[i];

  for(int i=0;i<N;i++)
    {
      gout>>a;

      if(a>K || a<1)
	    ex( "Numero di colore non valido", 0 );	    

      if(col[a])
	    ex( "Trovate due sequenze dello stesso colore non contigue", 0 );	    

      if (a==pre)
	{
	  sum+=v[i];
	}
      else 
	{
	  col[pre]=1;
	  pre=a;
	  sum=v[i];
	}
 
     if (sum>gval) 
	ex( "Il numero massimo di piani colorati dello stesso colore non corrisponde con la colorazione data", 0 );	    
    }
  col[a]=1;

  for(int i=1;i<=K;i++)
     if (!col[i]) 
	ex( "Non sono stati utilizzati tutti i colori", 0 );	    
    


  ex( NULL, 1 );

  return 0;
}

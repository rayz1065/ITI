/*

Grattacieli, (seconda selezione nazionale OII 2003)
Soluzione greedy O(n) con media

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

const int MAX_N = 400;
const int MAX_K = 400;

int v[MAX_N];

inline int max(int a, int b)
{
  return (a>b)?a:b;
}

int main()
{
  ifstream fin("input.txt");
  ofstream fout("output.txt");

  int media,i,j,K,N,k;

  fin>>N>>K;
  media=0;
  for(i=0;i<N;i++) 
    {
      fin>>v[i];
      media+=v[i];
    }
  media/=K;

  int sum=0, max=0;
  j=1;k=0;
  while(v[k]>media)
    {if (v[k]>max) max=v[k];v[k++]=j++;}

  for(i=k; i<N; i++)
    {

      if (j==K) {sum+=v[i]; v[i]=j; if (sum>max) max=sum;continue;}
      if (sum+v[i]<=media)
	{
	  sum+=v[i];
	  v[i]=j;
	}
      else
	{
	  sum=v[i];
	  v[i]=++j;
	}
      if (sum>max) max=sum;
      if (N-i-1==K-j) break;
    }

  if (N-i-1==K-j)  for(k=i; k<N; k++) v[k]=j++;
  fout<<max<<endl;
  for(i=0; i<N; i++) fout<<v[i]<<' ';
  fout<<endl;
  fout.close();
}

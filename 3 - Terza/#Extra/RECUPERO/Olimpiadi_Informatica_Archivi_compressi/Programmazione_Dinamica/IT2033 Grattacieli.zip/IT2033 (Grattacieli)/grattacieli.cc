/*

Grattacieli, (seconda selezione nazionale OII 2003)
Soluzione con algoritmo di programmazione dinamica O (kn^2)

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

const int MAX_N = 1000;
const int MAX_K = 400;

int m[MAX_K][MAX_N], u[MAX_K][MAX_N];

inline int max(int a, int b)
{
  return (a>b)?a:b;
}

int main()
{
  ifstream fin("input.txt");
  ofstream fout("output.txt");

  int i,j,K,N,k,a,p;

  fin>>N>>K;
  fin>>m[0][0];
  for(i=1;i<N;i++)
    {
      fin>>a;
      m[0][i]=m[0][i-1]+a;
    }
  
  for(i=1;i<K;i++)
    for(j=i;j<N;j++)
      {
	m[i][j]=INT_MAX;
	for(k=i-1;k<j;k++)
	  if ( (a=max(m[i-1][k],(m[0][j]-m[0][k]))) < m[i][j] )
	    {
	      m[i][j]=a;
	      u[i][j]=k;
	    }	
      }

  fout<<m[K-1][N-1]<<endl;

  p=j=N-1;
  for(i=K-1; i; i--)
    {
      for(k=j;k>u[i][j];k--) m[0][p--]=(i+1);
      j=u[i][j];
    }

  for(i=j; i>=0; i--) m[0][i]=1;
 
  for(i=0; i<N; i++) fout<<m[0][i]<<' ';
  fout<<endl;
  fout.close();

}

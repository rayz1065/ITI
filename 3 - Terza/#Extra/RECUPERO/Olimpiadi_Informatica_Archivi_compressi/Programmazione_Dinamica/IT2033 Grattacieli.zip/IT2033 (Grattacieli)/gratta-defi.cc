/*

Grattacieli, (seconda selezione nazionale OII 2003)
Soluzione non ottimale banale greedy O(n)

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

const int MAX_N = 100;
const int MAX_K = 100;

int v[MAX_N];

inline int max(int a, int b)
{
  return (a>b)?a:b;
}

int main()
{
  ifstream fin("input.txt");
  ofstream fout("output.txt");

  int i,j,K,N,k,a,p;

  fin>>N>>K;
  for(i=0;i<N;i++) fin>>v[i];

  int sum=0, max=0;
  for(i=0; i<N; i++)
    {
      if (i && v[i-1]==(i/K+1))
	sum+=v[i];   
      else sum=v[i];
      v[i]=(i/K+1);
      if (sum>max) max=sum;
    }
  fout<<max<<endl;
  for(i=0;i<N;i++) fout<<v[i]<<' ';
  fout.close();
}

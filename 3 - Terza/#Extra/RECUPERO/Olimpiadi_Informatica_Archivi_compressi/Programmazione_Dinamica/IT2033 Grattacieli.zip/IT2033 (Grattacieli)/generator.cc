#include <cstdlib>
#include <ctime>
#include <iostream>
#include <cmath>
#include <algorithm>
/*

genera una permutazione casuale di un array di interi riempito con legge:

v[i]=ini*exp(-(damp*i)/n)

dove 

0.0<damp<20; (smorzamento dell'esponenziale)
n � il numero di elementi del vettore.
ini � un valore inziale tale che ini*MAXN < 2^32 
(poich� la somma di tutti gli elementi nel vettore deve potere essere contenuta in un intero a 32 bit)

 */


using namespace std;

const int MAXN=1000;
const int MAXK=400;

int v[MAXN];

int main(int argc, char * argv[])
{

  int n,k;
  double damp;

  if (argc==4)
	{srand48(time(NULL)), srand(time(NULL));}
  else if (argc==5)
    	{srand48(atoi(argv[4]));srand(atoi(argv[4]));}
  if (argc<4)
    {

      cerr<< "Usage: "<<argv[0]<<" N, K, Damp, [Seed]"<<endl<<"0.0 <= Damp <= 50.0"<<endl;
      return 1;
    }
  
  damp=atof(argv[3]);
  if (damp<0.0 || damp > 50.0)
    {
      cerr<<"0.0 <= Damp <= 50.0"<<endl;
      return 1;
    }

  n=atoi(argv[1]);
  k=atoi(argv[2]);
  
  cout<< n<<' '<<k<<endl;

  int ini=rand()%MAXN+MAXN;
  for(int i=0;i<n;i++)    
    v[i]=int(double(ini)*exp((double(-i)/double(n))*damp)+1);

  random_shuffle(v,v+n);

  for(int i=0;i<n;i++) cout<<v[i]<<' ';
  cout<<endl;
    

  return 0;
}

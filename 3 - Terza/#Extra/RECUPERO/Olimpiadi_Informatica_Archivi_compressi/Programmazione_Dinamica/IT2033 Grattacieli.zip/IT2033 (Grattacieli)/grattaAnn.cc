/*

Grattacieli, (seconda selezione nazionale OII 2003)
Soluzione con algoritmo di simulated annealing

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <fstream>
#include <climits>
#include <algorithm>
#include <cmath>
#include <cstdlib>

using namespace std;

const int MAX_N = 1000;
const int MAX_K = 400;

const int loop = 50000;	// numero di iterazioni
const double T0=1000.0; // temperatura iniziale
const double Tn=1.0;    // temperatura finale
const double C=(log(Tn/T0) /loop);
const double k=exp(-10.0);

int inc[MAX_N];
int pos[MAX_K], optsol[MAX_K];
int N,K,hbest;

inline int max(int a, int b)
{
  return (a>b)?a:b;
}


inline int H()
//funzione hamiltoniana da minimizzare (somma delle distanze tra un ogni villaggio e l'ufficio ad esso piu' vicino)
{
  int max=inc[pos[0]];
  for(int i=1;i<K-1; i++)
      if (inc[pos[i]]-inc[pos[i-1]] > max)
	max=inc[pos[i]]-inc[pos[i-1]];
  if (max<inc[N-1]-inc[pos[K-2]]) max=inc[N-1]-inc[pos[K-2]];
  return max;
}


inline double cool(double t)
  // funzione di raffreddamento . T(t) = T0* ((TN/T0)^(t/loop))
{
  return T0*exp(t*C);
}

void annealing()
  // come da intestazione :)
{

  int jump,postmp[MAX_K];
    double p,p1, T;

    int hpred = H(), hval=hpred;
    hbest=hpred;

    srand(time(NULL));

    for(int j=0;j<K-1;j++) optsol[j]=pos[j];
    for (int i = 0; i < loop; i++) 
      {
	// Il seguente blocco perturba le posizione degli uffici in modo che il loro ordinamento sulla retta rimanga invariato.
	T = cool(i);

	//salvo pos
	for(int j=0;j<K-1;j++) postmp[j]=pos[j];
	
	//modifico pos
	for(int j=0;j<K-1;j++) 
	  {
	    p = (rand() / (RAND_MAX + 1.0));
	    jump=int((p-0.5)*10.0);
	    if (jump<0)
	      {
		if (!j)
		  {
		    if (pos[0]+jump>=0) pos[0]+=jump;
		  }
		else
		  if (pos[j]+jump>pos[j-1]) pos[j]+=jump;
	      }
	    else
	      {
		if (j==K-2)
		  {
		    if (pos[K-2]+jump<N-1) pos[K-2]+=jump;
		  }
		else
		  if (pos[j]+jump<pos[j+1]) pos[j]+=jump;		
	      }
	  }
	
	hpred=hval;
        hval = H();
	if (hval > hpred) 
	  {
	    //accetta una soluzione peggiorativa con una certa probabilita'
	    p = (rand() / (RAND_MAX + 1.0));
	    p1=exp((hpred-hval) / (k*T));
	    if (p > p1 ){
	      //ricopio postmp in pos;
	      for(int j=0;j<K-1;j++) pos[j]=postmp[j];
	      hval=hpred;
	    }
	  } 
	else if (hbest > hval)
	  //controlla se la soluzione e' migliore dell'ottimo corrente.
	  {
	    hbest = hval;
	    //salvo la soluzione
	    for (int j = 0; j < K-1; j++)
	      optsol[j] = pos[j];
	  }
      }
}



int main()
{
  ifstream fin("input.txt");
  ofstream fout("output.txt");

  int i,j,a;

  fin>>N>>K;
  fin>>inc[0];
  for(i=1;i<N;i++)
    {
      fin>>a;
      inc[i]=inc[i-1]+a;
    }

  //condizione iniziale;
  for(i=1;i<K;i++)
    pos[i-1]=(N*i)/K;

  annealing();

  fout<<hbest<<endl;
  for(i=0;i<=optsol[0];i++) fout<<1<<' ';
  for(i=1;i<K-1;i++)
    {
      for(j=optsol[i-1];j<optsol[i];j++)
	fout<<i+1<<' ';
    }
  for(i=optsol[K-2]+1;i<N;i++) fout<<K<<' ';
  fout<<endl;

  fout.close();

}

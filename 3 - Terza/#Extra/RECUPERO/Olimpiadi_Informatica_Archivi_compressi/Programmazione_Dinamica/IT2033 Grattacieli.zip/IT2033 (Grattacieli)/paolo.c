
#include <stdio.h>
#include <limits.h>

#define MAXN	350

#define max(a,b)	(((a)<(b))? (b) : (a))

int N, K;
int alt[MAXN];

// sot[i][k] = soluzione ottima per i primi i grattacieli, usando k colori (i=0,...,N; k=0,...,K)
// lb[i][k] = numero di grattacieli che usano il k-esimo colore nella soluzione ottima per i grattacieli

int sol[MAXN+1][MAXN+1], lb[MAXN+1][MAXN+1];

void printsol( int n, int k ) { 
	int i;

	if ( k == 0 ) return;
	printsol( n - lb[n][k], k-1 );
	for ( i = 0; i < lb[n][k]; i++ ) printf( "%d ", k );
}

int main() {
	int i, k, j, ult;

	scanf( "%d %d", &N, &K );	
	for ( i = 0; i < N; i++ ) scanf( "%d", &alt[i] );
	
	sol[0][0] = 0; lb[0][0] = 0; for ( i = 1; i <= N; i++ ) sol[i][0] = INT_MAX; 

	// Con k colori...
	for ( k = 1; k <= K; k++ ) 
		// I primi i grattacieli...
		for ( i = 0; i <= N; i++ ) {
			// Calcolo sol[i][k]
			sol[i][k] = INT_MAX;
			// Dimensione ultimo blocco: da 1 a i
			ult = 0;
			for ( j = 1; j <= i; j++ ) {
				ult += alt[ i - j ];	
				//printf( "per i=%d e k=%d considero j=%d (ult=%d, sol prec=%d)\n", i, k, j, ult, sol[i-j][k-1] );
				if ( max ( ult, sol[ i - j ][ k - 1 ] ) < sol[ i ][ k ] ) {
					//printf( "per i=%d e k=%d considero j=%d (ult=%d, sol prec=%d) PRESO\n", i, k, j, ult, sol[i-j][k-1] );
					sol[ i ][ k ] = max( ult, sol[ i - j ][ k - 1 ] );
					lb[ i ][ k ] = j;
				}
			}
		}
	printf( "%d\n", sol[N][K] );
	printsol( N, K );
	printf( "\n" );
	return 0;
}


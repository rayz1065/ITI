#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

void ex( char *msg, float res ) {
   if (msg) fprintf(stderr, "%s", msg);
   printf("%f\n",res);
   exit(0);
}

int main(int argc, char *argv[]) {
  FILE *in, *out, *des;
  int Ver, N, CMax, R;

  int i, j;
  int n, c;
  int nexti, nextc;
  char buffer[1024];

  int CN, Ci, isRight;

  assert( in = fopen(argv[1], "r") );

  assert( des = fopen(argv[2], "r") );

  if ( (out = fopen(argv[3], "r")) == NULL ) ex("Nessun file di output", 0);

  assert( fscanf(in, " %d %d", &N, &CMax) == 2 );
  assert( fscanf(des, " %d", &R) == 1 );

  if ( fscanf(out, " %d", &Ver) != 1 ) ex( "Impossibile leggere il numero di verniciamenti.", 0 );

  if ( R == -1 && Ver == -1 ) ex( NULL, 1 );
  if ( R != Ver ) {
	if ( R < Ver ) ex( "Soluzione errata ", 0 );
	else if ( R > Ver ) ex( "Soluzione subottima ", 0 );
	ex( NULL, 1 );
  }

  n = 0;

  if ( fscanf(out, " %d %d", &nexti, &nextc) != 2 ) {
    sprintf( buffer, "Troppe poche coppie (dichiarate %d, effettive %d).", Ver, n);
    ex( buffer, 0 );
  }

  for ( i = 1 ; i <= N ; i++ ) {
    if ( i == nexti ) {
      n++;

      c = nextc;

      if ( n < Ver ) 
        if ( fscanf(out, " %d %d", &nexti, &nextc) != 2 ) {
          sprintf( buffer, "Troppe poche coppie (dichiarate %d, effettive %d).", Ver, n);
          ex( buffer, 0 );
        }
    }

    assert( fscanf(in, " %d", &CN) == 1 );

    isRight = 0;
    for ( j = 0 ; j < CN ; j++ ) {
      assert( fscanf(in, " %d", &Ci) == 1 );
      
      if ( Ci == c ) isRight = 1;
    }

    if ( !isRight ) {
      sprintf( buffer, "Celebrita non entra in macchina (celebrita %d, colore attuale %d).", i, c);
      ex( buffer, 0 );
    }
  }

  ex( NULL, 1 );
}

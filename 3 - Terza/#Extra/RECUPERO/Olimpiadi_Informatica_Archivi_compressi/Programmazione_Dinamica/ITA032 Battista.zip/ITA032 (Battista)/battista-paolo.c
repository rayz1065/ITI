#include <stdio.h>
#include <limits.h>
#include <assert.h>

#define CMAX_UP	200
#define N_UP	1000
#define infty   ( N_UP*N_UP )

int N, Cmax;
int lun[ N_UP + 1 ][ CMAX_UP ];
int cc[ N_UP + 1 ];

int main() {
	int i, c, ncol, k, mn, imn;

	scanf( "%d %d", &N, &Cmax );

	for ( k = 0; k < Cmax; k++ ) lun[ 0 ][ k ] = 1;

	for ( i = 1; i <= N; i++ ) {
		scanf( "%d", &ncol );
		for ( k = 0; k < Cmax; k++ ) lun[ i ][ k ] = infty;
		for ( k = 0; k < ncol; k++ ) {
			scanf( "%d", &c ); c--;
			mn = lun[ i - 1 ][ c ];
			if ( c > 0 && lun[ i - 1 ][ c - 1 ] + 1 < mn )	mn = lun[ i - 1 ][ c - 1 ] + 1;
			if ( c < Cmax - 1 && lun[ i - 1 ][ c + 1 ] + 1 < mn ) mn = lun[ i - 1 ][ c + 1 ] + 1;
			lun[ i ][ c ] = mn;
		}
	}

	mn = infty; imn = -1;
	for ( i = 0; i < Cmax; i++ ) if ( lun[ N ][ i ] < mn ) mn = lun[ N ][ imn = i ];
	
	if ( mn == infty ) {
		printf( "-1\n" );
		return 0;
	}

	for ( i = N; i > 0; i-- ) {	
		cc[ i ] = imn;
		if ( lun[ i ][ imn ] != lun[ i - 1 ][ imn ] ) 
			if ( imn > 0 && lun[ i - 1 ][ imn - 1 ] + 1 == lun[ i ][ imn ] ) imn--;
			else if ( imn < Cmax - 1 && lun[ i - 1 ][ imn + 1 ] + 1 == lun[ i ][ imn ] ) imn++;
			else assert( 0 );
	}

	printf( "%d\n", mn );
	cc[ 0 ] = -1;
	for ( i = 1; i <= N; i++ ) if ( cc[ i ] != cc[ i - 1 ] ) printf( "%d %d\n", i, cc[ i ] + 1 );
	return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define min(a, b) ( (a) < (b) ? (a) : (b) )

typedef struct {
  int Time, Color;
} pair;

int N, CMax;
int **Dinamica, **Piace;
pair *Flow;

int main() {
  int i, j;
  int n, c;
  int Best, prevBest;
  int Color, prevColor;
  
  /* Inizializzazione */

  scanf(" %d %d", &N, &CMax);

  Flow = calloc(N, sizeof(pair));

  Dinamica = calloc(N, sizeof(int*));
  Piace = calloc(N, sizeof(int*));

  for ( i = 0 ; i < N ; i++ ) {
    Dinamica[i] = calloc(CMax, sizeof(int));
    Piace[i] = calloc(CMax, sizeof(int));
  }

  for ( i = 0 ; i < N ; i++ ) {
    scanf(" %d", &n);

    for ( j = 0 ; j < n ; j++ ) {
      scanf(" %d", &c);

      Piace[i][c - 1] = 1;
    }
  }
      
  /* Inizio Dinamica */

  for ( j = 0 ; j < CMax ; j++ )
    if ( Piace[0][j] ) {
      Dinamica[0][j] = 1;

      Best = 1;
    } else
      Dinamica[0][j] = INT_MAX;


  for ( i = 1 ; i < N ; i++ ) {

    prevBest = Best;
    Best = INT_MAX;

    for ( j = 0 ; j < CMax ; j++ )
      if ( Piace[i][j] ) {
        Dinamica[i][j] = Dinamica[i - 1][j];

        if ( j > 0 && Dinamica[i - 1][ j - 1 ] < Dinamica[i][j] )
          Dinamica[i][j] = Dinamica[i - 1][ j - 1 ] + 1;

        if ( j < CMax - 1 && Dinamica[i - 1][ j + 1 ] < Dinamica[i][j] )
          Dinamica[i][j] = Dinamica[i - 1][ j + 1 ] + 1;

        /*        printf("%d ", Dinamica[i][j]);*/

        /* Nella versione vecchia 
           Dinamica[i][j] = min(Dinamica[i - 1][j], prevBest + 1); */
      
        Best = min(Dinamica[i][j], Best);
      } else
        Dinamica[i][j] = INT_MAX;

  }

  /*
    Ora abbiamo la matrice piena ed in best il minor numero di
    verniciamenti
  */

  if ( Best == INT_MAX ) {
    printf("-1\n");
    
    return 0;
  }

  /* Ricostruzione lista verniciamenti */

  for ( j = 0 ; j < CMax ; j++ ) 
    if ( Dinamica[N - 1][j] == Best ) {
      Color = j;
      break;
    }

  n = Best;

  for ( i = N - 2 ; i >= 0 ; i-- ) {
    prevColor = Color;

    if ( Dinamica[i][prevColor] == Dinamica[i + 1][prevColor] )
      Color = prevColor;
    else {
      if ( prevColor > 0 && Dinamica[i][ prevColor - 1 ] != INT_MAX &&
           Dinamica[i][ prevColor - 1 ] + 1 == Dinamica[i + 1][prevColor] ) {
        Color = prevColor - 1;
      } else if ( prevColor < CMax - 1 && Dinamica[i][ prevColor + 1 ] != INT_MAX &&
                  Dinamica[i][ prevColor + 1 ] + 1 == Dinamica[i + 1][prevColor] ) {
        Color = prevColor + 1;
      }
    }

    if ( Color != prevColor ) {
      n--;
      
      Flow[n].Time = i + 2;
      Flow[n].Color = prevColor + 1;
    }
  }

  n--;
  /* n == 0 */
  Flow[n].Time = 1;
  Flow[n].Color = Color + 1;


  /* Ora abbiamo in Flow[i] il riverniciamento i */

  /* Stampa soluzione */

  printf("%d\n", Best);

  for ( n = 0 ; n < Best ; n++ )
    printf("%d %d\n", Flow[n].Time, Flow[n].Color);

  return 0;
}

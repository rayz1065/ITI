/* 
ioi2005 - Fase nazionale
Messaggi - Luca Foschini

Soluzione ricorsiva
*/

#include <iostream>
#include <set>
#include <string>

using namespace std;

const int NMAX=100000;

int n,cm_len=4;
string s;
set<string> cw;

int count(int p)
{
  string sub;
  int l,sum;
  if (p==n)
    return 1;
  else
    {
      sum=0;sub="";
      for(l=1;l<=cm_len;l++)
	{
	  if (p+l>n) break;
	  sub+=s[p+l];
	  if (cw.find(sub)!=cw.end()) sum+=count(p+l);	    
	  sum%=10;
	}
      return sum;
    }
}

int main()
{

  cw.insert("0"); cw.insert("00"); cw.insert("001"); cw.insert("010"); cw.insert("0010");
  cw.insert("0100"); cw.insert("0110"); 

  int i,a;
  cin>>n;

  s="0";
  for(i=1;i<=n;i++) {cin>>a; s+=char(a+'0');}
  cout<<count(0)<<endl;

  return 0;
}

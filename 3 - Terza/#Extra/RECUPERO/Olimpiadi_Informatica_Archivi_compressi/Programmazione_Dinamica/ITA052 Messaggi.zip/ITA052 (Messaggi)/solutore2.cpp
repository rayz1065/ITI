/* 
ioi2005 - Fase nazionale
Messaggi - Luca Foschini
*/

#include <iostream>
#include <set>
#include <string>

using namespace std;

const int NMAX=200000;

int c[NMAX+1];

int main()
{
  set<string> cw;
  cw.insert("0"); cw.insert("00"); cw.insert("001"); cw.insert("010"); cw.insert("0010");
  cw.insert("0100"); cw.insert("0110"); 

  int n,a,i,j,cm_len=4;
  string s, sub;

  cin>>n;

  c[0]=1;

  for(i=1;i<=n;i++) {cin>>a; s+=char(a+'0');}

  for(i=1;i<=n;i++)
    {
      sub="";
      for(int l=1;l<=(cm_len>i?i:cm_len);l++)
	{
	  sub=s[i-l]+sub;
	  if (cw.find(sub)!=cw.end()) {
	    c[i]+=c[i-l];
	    c[i]%=10;
	  }
	}
    }
  cout<<c[n]<<endl;

  return 0;
}

/*
  Flavio Chierichetti
  Messaggi
  
  Non testato completamente.
*/

#include <stdio.h>
#define MAX_WORDS 100
#define MAX_WORD_LENGTH 100
#define STDIO
/*#define DEBUG*/

int N, *Message, *Dynamic;

/* Codewords ended by semicolons */
char *Code = "0;00;001;010;0010;0100;0110;";

int M, Length[MAX_WORDS], Words[MAX_WORDS][MAX_WORD_LENGTH];

int main(int argc, char *argv[]) {
  FILE *in, *out;
  int i, j, k;

  int flag;

  char buffer[MAX_WORD_LENGTH];

#ifdef STDIO
  in = stdin;
  out = stdout;
#else
  in = fopen("input.txt", "r");
  out = fopen("output.txt", "w");
#endif

  /* Loading words */
  for ( i = 0, j = 0 ; Code[i] != '\0' ; i++ ) {
    switch ( Code[i] ) {
    case '0':
      Words[M][j] = 0;
      Length[M]++;
      j++;
      break;

    case '1':
      Words[M][j] = 1;
      Length[M]++;
      j++;
      break;

    case ';':
      M++;
      j = 0;
      break;

    default:
      exit(1);
    }
  }

#ifdef DEBUG
  for ( i = 0 ; i < M ; i++  ) {
    for ( j = 0 ; j < Length[i] ; j++  ) {
      fprintf(stderr, "%d", Words[i][j]);
    }
    fprintf(stderr, "\n");
  }
#endif

  
  /* Reading input */
  fscanf(in, " %d", &N);
 
  Message = (int*) calloc(sizeof(int), N);
  Dynamic = (int*) calloc(sizeof(int), N);
 
  for ( i = 0 ; i < N ; i++ )
    fscanf(in, " %d", Message + i);

  fclose(in);

  for ( i = 0 ; i < N ; i++ )
    for ( j = 0 ; j < M ; j++ ) {

      /* If the first char index is non-negative */
      if ( (i - Length[j]) == -1 ||
	   ( ((i - Length[j]) >= 0) && (Dynamic[i - Length[j]] > 0) ) )
	flag = 1;
      else
	flag = 0;

      for ( k = 0 ; flag && k < Length[j] ; k++ )
	if ( Words[j][k] != Message[i - Length[j] + 1 + k] )
	  flag = 0;

      if ( flag ) {

#ifdef DEBUG
	fprintf(stderr, "char %d: word %d ok (length %d).\n", i, j, Length[j]);
	if ( (i - Length[j]) >= 0 )
	  fprintf(stderr, "previous: %d, old: %d\n", Dynamic[i - Length[j]], Dynamic[i]);
	else
	  fprintf(stderr, "old: %d\n", Dynamic[i]);
#endif

	if ( (i - Length[j]) >= 0 )
	  Dynamic[i] += Dynamic[i - Length[j]];
	else
	  Dynamic[i] += 1;
	Dynamic[i] %= 10;
	  
      }
    }

#ifdef DEBUG
  for ( i = 0 ; i < N ; i++ )
    fprintf(stderr, "%d ", Dynamic[i]);
  fprintf(stderr, "\n");
#endif

  fprintf(out, "%d\n", Dynamic[N - 1]);

  return 0;
}

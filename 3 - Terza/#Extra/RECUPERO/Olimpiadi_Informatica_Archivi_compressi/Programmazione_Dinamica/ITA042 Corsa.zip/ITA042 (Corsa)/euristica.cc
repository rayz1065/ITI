#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

const int M=256;
const int N=256;

int mat[N*M];
int seen[N*M];
int val[N*M];
int que[N*M];


int main()
{

  int i,j,m,n,name,ci,cj,a,tmp,q,imin;
  ifstream in("input.txt");
  ofstream out("output.txt");
  in>>m>>n;
  for(i=0;i<m;i++)
    for(j=0;j<n;j++)
      in>>mat[i*M+j];


  //dijkstra n^2 volte.

  memset(seen,0,N*M);
  for(i=0;i<m;i++) 
    {
      que[i]=i*M;
      val[que[i]]=mat[i*M];
    }
  q=m;
  while(q)
    {
      imin=0;
      for(j=1;j<q;j++) if (val[que[j]]<val[que[imin]])
	imin=j; //trovato l'indice del minimo
      ci=que[imin]/M;
      cj=que[imin]%M;

      if(ci>0 && !seen[ a=((ci-1)*M+cj) ] )//nord
	{
	  j=0;
	  while(que[j]!=a && j<q) j++; //trovato l'indice
	  if (j==q)
	    {
	      que[q++]=a;
	      val[a]=val[que[imin]]+mat[a];
	    }
	  else
	    if (val[que[j]]>val[que[imin]]+mat[a])
	      val[que[j]]=val[que[imin]]+mat[a];
	      
	}

      if(ci<m-1 && !seen[a=((ci+1)*M+cj)])//sud
	{
	  j=0;
	  while(que[j]!=a && j<q) j++; //trovato l'indice
	  if (j==q)
	    {
	      que[q++]=a;
	      val[a]=val[que[imin]]+mat[a];
	    }
	  else
	    if (val[que[j]]>val[que[imin]]+mat[a])
	      val[que[j]]=val[que[imin]]+mat[a];
	      
	}
		
      if(cj<n-1 && !seen[a=(ci*M+cj+1)])//est
	{
	  j=0;
	  while(que[j]!=a && j<q) j++; //trovato l'indice
	  if (j==q)
	    {
	      que[q++]=a;
	      val[a]=val[que[imin]]+mat[a];
	    }
	  else
	    if (val[que[j]]>val[que[imin]]+mat[a])
	      val[que[j]]=val[que[imin]]+mat[a];
	}

      seen[que[imin]]=1;	  
      que[imin]=que[--q];

    }


  int min=INT_MAX;
  for(j=0;j<m;j++)
    if (val[j*M+n-1]<min)
      min=val[j*M+n-1];


  out<<min<<endl;
  return 0;
}

#!/bin/bash

generatore='./generatore'
solutore='./solutore'
iodir='./InputOutput'

primi="11;
17;
23;
37;
43;
53;
61;
73;
89;
101;
113; 
131;
149;
167;
181;
197;
211;
229;
241;
263;
271;
283;
313;
347;"

n=0

echo -e "5 5\n90 5 10 23 44\n1 8 8 21 32\n4 15 9 10 11\n3 12 5 21 23\n82 13 6 37 45\n" > $iodir/input$n.txt

n=$((n + 1))

for (( i = 1 ; i <= 8 ; i++ )); do
    s=$(echo $primi | cut -d";" -f $i)
    $generatore 256 128 17280 $s > $iodir/input$n.txt
    n=$((n + 1))
done

for (( i = 9 ; i <= 16 ; i++ )); do
    s=$(echo $primi | cut -d";" -f $i)
    $generatore 128 256 17280 $s > $iodir/input$n.txt
    n=$((n + 1))
done

for (( i = 17 ; i <= 24 ; i++ )); do
    s=$(echo $primi | cut -d";" -f $i)
    $generatore 256 256 17280 $s > $iodir/input$n.txt
    n=$((n + 1))
done


for (( i = 0 ; i <= 24 ; i++ )); do
    $solutore < $iodir/input$i.txt > $iodir/output$i.txt
done

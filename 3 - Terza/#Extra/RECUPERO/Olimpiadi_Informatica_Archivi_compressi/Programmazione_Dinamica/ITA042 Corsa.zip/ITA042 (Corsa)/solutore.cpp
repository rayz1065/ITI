#include <fstream>
#include <iostream>
#include <ios>

using namespace std;

//char *InName = "input.txt";
//char *OutName = "output.txt";

const int MAXSIZE = 256;
const int MAX = 17280 * 256 * 256 + 3;
int Matrice[MAXSIZE][MAXSIZE];
int Ottimi[MAXSIZE][MAXSIZE];
int numrighe, numcol;

void ReadInput( )
{
	if(cin == NULL)
		{
		cerr << "Error Opening Input"  << endl;
		exit(1);
		}
	else
		{
		int row, col;
		cin >> numrighe;
 		cin >> numcol;
		for(row = 0; row < numrighe; row++)
			for(col = 0; col < numcol; col++)
				{
				  Matrice[row][col] = MAX;	
            			  Ottimi[row][col] = MAX;
				}

		for(row = 0; row < numrighe; row++)
			for(col = 0; col < numcol; col++)
				{
				cin >> Matrice[row][col];
				if(Matrice[row][col] < 0 || Matrice[row][col] > MAX)
					{
					cerr << "Input errato\n";
					exit(2);
					}
				}
		}
}

int min(int i1, int i2, int i3){
  if (i1>i2)
     i1=i2;
  if (i3>i1)
	  return i1;
  return i3;
}

int Search(int row, int col)
{
	if (row==numrighe-1)
   	return Matrice[row][col] + Ottimi[row][col+1];
   return Matrice[row][col] + min(Ottimi[row][col+1], Search(row+1, col), MAX);
}

void CalcolaOttimi()
{
	int row, col;
	for(row=0;row<numrighe;row++)
   	    Ottimi[row][numcol-1]=Matrice[row][numcol-1];
   	for(col=numcol-2;col>=0;col--){
	// cerr << "Ottimi colonna" << col << endl;
	   for(row=0;row<numrighe;row++){
      		int value=MAX;
         	if (row<numrighe-1)
			value=Search(row+1,col);
         	if (row>0)
	      		Ottimi[row][col]=Matrice[row][col]+ min(Ottimi[row][col+1],
            					value,Ottimi[row-1][col]);
         	else
	      		Ottimi[row][col]=Matrice[row][col]+
				min(Ottimi[row][col+1],value,MAX);
	//  cerr << row << ", " << col << " : " << Ottimi[row][col] << endl;
     }
  }
}


int minimo(int min[]){
 int minimo=MAX;
 for(int i=0;i<numrighe;i++)
 	if (min[i]<minimo)
   	minimo=min[i];
 return minimo;
}

int main()
{
	int min;
	ReadInput( );
   int minuti[MAXSIZE];
	// Calcola i valori ottimi da un qualsiasi punto della matrice ad
   // un punto di uscita
   CalcolaOttimi();
   // Copia i valori minimi dei punti di ingresso in un array
	for(int row = 0; row < numrighe; row++){
	   //cerr<< "Ottimo " << row << " = " << Ottimi[row][0] << endl;
      	   minuti[row]=Ottimi[row][0];
          }
   
	if(numrighe==0) min = 0;
   else
   	min=minimo(minuti);
   // copia il tempo minimo in formato ore:minuti nel file output
   cout << min << endl;

	return 0;
}

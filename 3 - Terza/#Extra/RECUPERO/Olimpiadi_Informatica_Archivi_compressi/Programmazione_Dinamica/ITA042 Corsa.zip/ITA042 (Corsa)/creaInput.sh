#!/bin/bash

generatore='./generatore'
solutore='./solutore'
iodir='./InputOutput'

#file di esempio
echo -e "5 5\n90 5 10 23 44\n1 8 8 21 32\n4 15 9 10 11\n3 12 5 21 23\n82 13 6 37 45\n" > input0.txt
#N P M
desc="5 5 17280 0;
5 3 17280 0;
3 5 17280 0;
10 20 17280 0;
20 15 17280 0;
40 50 17280 0;
35 70 17280 0;
5 85 17280 0;
95 5 17280 0;
60 60 17280 0;
70 80 17280 0;
90 80 17280 0;
100 100 17280 0;
120 120 17280 0;
150 120 17280 0;
160 150 17280 0;
180 190 17280 0;
200 205 17280 0;
210 5 17280 0;
240 210 17280 0;
230 220 17280 0;
256 256 17280 0;
256 256 17280 0;
256 256 17280 0;"

for((i=1;i<24;i++)); do
    s=$(echo $desc | cut -d";" -f $i)
    $generatore $s > input$i.txt
done
 
for (( i = 0 ; i <= 24 ; i++ )); do
    $solutore < input$i.txt > output$i.txt
done

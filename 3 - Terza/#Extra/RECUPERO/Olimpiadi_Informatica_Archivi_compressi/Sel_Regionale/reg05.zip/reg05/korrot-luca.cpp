#include <iostream>

using namespace std;

int map[211][211];
char d2c[4]={'A','D','B','S'};

int main()
{
  int n,k,p,a,b,m,x,y,d,f=0;
  cin>>m>>n>>k>>p; //mi piace di piu invertire
  map[1][k]=4;map[m][p]=-1;
  while(cin>>a>>b && a!=0) map[a][b]=1;
  x=k;y=1;d=0;
  while(true)
    {
      if (map[y][x]==3){cout<<endl<<'C'<<endl; break;}
      if (x!=k || y!=1) {cout<<d2c[d];}
      if (map[y][x]==-1){cout<<endl<<'P'<<endl; break;}
      map[y][x]=3; //gia visitato;
      if (y!=m && map[y+1][x]<=0) 
	{
	  d=0;
	  y++;
	}
      else
	{
	  if (y==m)
	    {
	      if (x-p>0 && map[y][x-1]<=0)
		{
		  d=3;
		  x--;
		}
	      else
		{
		  if (x-p<0 && map[y][x+1]<=0)
		    {
		      d=1;
		      x++;
		    }
		  else
		    {
		      d=2;
		      f=1;
		      y=y-1;
		    }
		}

	    }
	  else // y!=m e sopra ostacolo o gia visitato
	    {
	      if (f)
		{
		  if (x-p<0 && map[y][x+1]<=0)
		    {
		      d=1;
		      x++;
		    }
		  else
		    {
		      if (x-p>0 && map[y][x-1]<=0)
			{
			  d=3;
			  x--;
			}
		      //else errore di gia' visitato
		    }
		}
	      else
		{
		  if (x!=n && map[y][x+1]<=0)
		    {
		      d=1;
		      x++;
		    }
		  else
		    {
		      if (x==n && map[y][x-1]<=0)
			{
			  d=3;
			  x--;
			}

		    }
		}
	    }
	}
    }
  return 0;
}

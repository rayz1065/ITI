#include <stdio.h>
#include <ctype.h>

int main()
{
	int A,B,N,s;
    int totA=0;
    int totB=0;
    int i,j;
    int bidA,bidB;

    int pos[100];
    int cap[100];
    int versA[100];
    int versB[100];

    for (i=0;i<100;i++) {
        pos[i]=i;
        versA[i]=0;
        versB[i]=0;
    }

    scanf("%d %d %d",&A,&B,&N);

    for (i=0;i<N;i++) {
        scanf("%d",&cap[i]);
    }

    for (i=0;i<(N-1);i++) {
        for (j=i;j<N;j++) {
            if (cap[j]<cap[i]) {
               s=cap[i];
               cap[i]=cap[j];
               cap[j]=s;
               s=pos[i];
               pos[i]=pos[j];
               pos[j]=s;
            }
        }
    }

    bidA=0;
    while (totA<A) {
        versA[pos[bidA]]=cap[bidA];
        totA+=cap[bidA];
        bidA++;
    }

    bidB=0;
    while (totB<B) {
        versB[pos[(N-1)-bidB]]=cap[(N-1)-bidB];
        totB+=cap[(N-1)-bidB];
        bidB++;
    }

    for (i=0;i<N;i++) {
        printf("%d %d\n",versA[i],versB[i]);
    }

    return 0;
}


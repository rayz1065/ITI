/* risolve il problema della poltrona di Korrot, v2.3 */
/* settare SCACCHIERA=1 per ottenere una stampa della scacchiera */

#include <stdio.h>
#include <stdlib.h>

/* direzioni */
typedef int Direzione;
#define D_ALTO		1
#define D_BASSO		2
#define D_DESTRA	3
#define D_SINISTRA	4

typedef int Boolean;
#define TRUE	1
#define FALSE	0

/* stati delle caselle della scacchiera */
typedef char Stato;
#define C_LIBERA	1
#define C_OSTACOLO	2
#define C_POLTRONA	3
#define C_VISITATA	4

Stato scacchiera[201][201];

int N, M;		/* dimensioni scacchiera */
int kr, kc;		/* riga, colonna in cui si trova Korrot */
int k0r, k0c;		/* riga, colonna iniziali di Korrot (solo per stampare) */
int pc;			/* colonna in cui si trova la poltrona */


int DEBUG = 0;		/* set to 1 for printing debug info */
int SCACCHIERA = 0;	/* set to 1 for printing the board at the end of the game */


void stampa_scacchiera(void)
{
	int i, j;

	printf("\n");
	for (i=N+1; i>=0; i--, printf("\n"))
		for (j=0; j<=M+1; j++)
		{
			if (i == k0r && j == k0c)
				putchar('*');
			else if (i == kr && j == kc)		/* Korrot */
				putchar('K');
			else if (i == N && j == pc)	/* Poltrona */
				putchar('P');
			else if (scacchiera[i][j] == C_OSTACOLO)
				putchar('@');
			else if (scacchiera[i][j] == C_LIBERA)
				putchar(' ');
			else if (scacchiera[i][j] == C_VISITATA)
				putchar('.');
			else putchar('?');
		}

	putchar('\n');
	putchar('\n');
}


/* Korrot ha trovato la poltrona */
void vittoria(void)
{
	printf("\nP\n");
	if (SCACCHIERA)
	{
		stampa_scacchiera();
		printf("(Se non vuoi stampare la scacchiera, "
			"ricompilami con SCACCHIERA=0)\n");
	}
	exit(0);
}


/* Korrot non puo' piu' muoversi e abbandona */
void confusione(void)
{
	printf("\nC\n");
	if (SCACCHIERA)
	{
		stampa_scacchiera();
		printf("(Se non vuoi stampare la scacchiera, "
			"ricompilami con SCACCHIERA=0)\n");
	}
	exit(0);
}


/*
 * mossa in una direzione: D_ALTO, D_BASSO, D_DESTRA, D_SINISTRA
 * ritorna TRUE se la mossa e' stata compiuta OK, altrimenti FALSE
 * Se la mossa e' quella vincente (poltrona), il programma termina.
 */
Boolean mossa(Direzione d)
{
	int r, c;
	char out;

	switch(d)
	{
	case D_ALTO:
		r = kr + 1;
		c = kc;
		out = 'A';
		break;
	case D_BASSO:
		r = kr - 1;
		c = kc;
		out = 'B';
		break;
	case D_DESTRA:
		r = kr;
		c = kc + 1;
		out = 'D';
		break;
	case D_SINISTRA:
		r = kr;
		c = kc - 1;
		out = 'S';
		break;
	default:
		printf("*mossa(): direzione non ammessa (%d)\n", d);
		return 0;
	}

	/* mossa impossibile */
	if (scacchiera[r][c] == C_OSTACOLO || scacchiera[r][c] == C_VISITATA)
		return 0;

	/* mossa possibile: facciamola */
	putchar(out);
	kr = r;
	kc = c;

	if (scacchiera[kr][kc] == C_POLTRONA)	/* urrah! */
		vittoria();
	else
	{
		scacchiera[kr][kc] = C_VISITATA;
		if (DEBUG)
		{
			stampa_scacchiera();
		}
		return 1;
	}
	return 0;
}





int main(void)
{
	int r, c;	/* riga e colonna (valori temporanei) */
	int i, j;
	Direzione dirpoltrona;
	Boolean devo_rientrare;


	/* lettura input: dimensioni scacchiera */
	scanf("%d %d", &N, &M);

	/* inizializzazione tecnicamente non necessaria */
	for (i=1; i<=N; i++)
		for(j=1; j<=M; j++)
			scacchiera[i][j] = C_LIBERA;

	/* bordiamo la scacchiera di ostacoli fittizi (sentinelle) */
	for (i=0; i<=N+1; i++)
		scacchiera[i][0] = scacchiera[i][M+1] = C_OSTACOLO;
	for (j=0; j<=M+1; j++)
		scacchiera[0][j] = scacchiera[N+1][j] = C_OSTACOLO;

	kr = 1;
	/* lettura input: colonne iniziali Korrot e poltrona */
	scanf("%d %d", &kc, &pc);
	scacchiera[N][pc] = C_POLTRONA;
	k0r = kr;
	k0c = kc;

	/* lettura input: ostacoli */
	do
	{
		scanf("%d %d", &r, &c);
		scacchiera[r][c] = C_OSTACOLO;
	} while (r != 0 && c != 0);


	if (DEBUG)
		stampa_scacchiera();

	/*  prima raggiungiamo la riga N */
	while(kr < N)
	{
		if (!mossa(D_ALTO))
		{
			if (kc == M)		/* in colonna M svolta a sinistra */	
			{
				if(!mossa(D_SINISTRA))
					confusione();
			}
			else			/* normalmente, svolta a destra */
				if(!mossa(D_DESTRA))
					confusione();
		}
	}

	/* andiamo a destra o sinistra, a seconda se la poltrona
		sta a destra o a sinistra */
	dirpoltrona = (pc > kc) ? D_DESTRA : D_SINISTRA;

	devo_rientrare = FALSE;		/* mi sono allontanato dalla riga N? */
	while (TRUE)
	{
		if (devo_rientrare)
			mossa(D_ALTO);
		if( !mossa(dirpoltrona) )
		{
			if ( devo_rientrare || !mossa(D_BASSO) )
				confusione();
			else
				devo_rientrare = TRUE;
		}
	}
	return 0;
}



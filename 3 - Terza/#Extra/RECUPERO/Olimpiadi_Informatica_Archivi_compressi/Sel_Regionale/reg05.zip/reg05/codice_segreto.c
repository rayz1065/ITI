/* risolve il problema del codice segreto di Chicco&Spillo, v1.1 */

#include <stdio.h>
#include <ctype.h>

char codice[] =
{
	'E',	/* A */
	'C',	/* B */
	'D',	/* C */
	'F',	/* D */
	'I',	/* E */
	'G',	/* F */
	'H',	/* G */
	'J',	/* H */
	'O',	/* I */
	'K',	/* J */
	'L',	/* K */
	'M',	/* L */
	'N',	/* M */
	'P',	/* N */
	'U',	/* O */
	'Q',	/* P */
	'R',	/* Q */
	'S',	/* R */
	'T',	/* S */
	'V',	/* T */
	'Y',	/* U */
	'W',	/* V */
	'X',	/* W */
	'Z',	/* X */
	'A',	/* Y */
	'B',	/* Z */
};



int main()
{
	int c;
	char x;

	while((c=getchar())!='\n')   // N non c'e' veramente bisogno di conoscerlo.
	  ;

	while((c=getchar())!=EOF)
	{
		if (isalpha(c))			/* lettere */
			x = codice[toupper(c) - 'A'];
		else if (isdigit(c))		/* cifre */
			x = (c - '0' + 1) % 10 + '0';
		else				/* altro */
			x = c;

		if (islower(c))			/* aggiusta maiuscole/minuscole */
			putchar(tolower(x));
		else
			putchar(x);
	}
	return 0;
}


/*
** libreria.c
**
** Contiene il codice di supporto per il test della prova
** regionale delle Olimpiadi 2004
**
*/

#include "libreria.h"

int contaPiante(FILE *f, Tconfig *c){
  char b[32];

  c->piante = 0;
  fscanf(f,"%d\n", &(c->eliminare));
  while(fgets(b,32,f)!=NULL)
    c->piante++;

  rewind(f);
  return c->piante;
}

void caricaPiante(FILE *f, Tconfig *c){
  unsigned k;
  
  rewind(f);
  fscanf(f, "%d\n", &k);
  for(k=0;k<c->piante;k++)
    fscanf(f,"%d %d\n", &(c->aiola)[k].x, &(c->aiola)[k].y);
}

void visitaAiola(punto aiola[], int n)
{
  int k;
  
  for(k=0;k<n;k++)
    printf("(%d,%d)\n", aiola[k].x, aiola[k].y);
  
}

int confrontaPuntiY(const void *a, const void *b){
  return ((punto *)a)->y - ((punto *)b)->y;
}

int confrontaPuntiX(const void *a, const void *b){
  int ax,ay;
  int v;
  ax = ((punto *)a)->x;
  ay = ((punto *)b)->x;
  v = ((punto *)a)->x - ((punto *)b)->x;
  return v;
}

int confrontaPuntiXY(const void *a, const void *b){

  int ax, bx;
  ax = ((punto *)a)->x;
  bx = ((punto *)b)->x;

  if (((punto *)a)->x > ((punto *)b)->x)
    return 1;
  else if(((punto *)a)->x == ((punto *)b)->x)
    return (((punto *)a)->y - ((punto *)b)->y);
  else
    return -1;
}

long int distanza(punto a, punto b){
  return (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y);
}

void salva(FILE *f, Tconfig config){
  int first, k;

  //last = config.piante;
  first = config.piante;

  //printf("%d %d", first, config.eliminare);
  //visitaAiola(&config.aiola[first], config.eliminare);
  printf("%d\n", (&(config.aiola[first]))[0].x);

  qsort(&(config.aiola[first]),
	config.eliminare,
	sizeof(punto),
	confrontaPuntiXY);

  for(k=first; k<(config.piante+config.eliminare); k++)
    fprintf(f, "%d %d\n", config.aiola[k].x, config.aiola[k].y);
}

void salvaAiola(FILE *f, Tconfig config){
  int k;

  fprintf(f, "%d\n", config.eliminare);
  for(k=0; k<config.piante; k++)
    fprintf(f, "%d %d\n", config.aiola[k].x, config.aiola[k].y);
}

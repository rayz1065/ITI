#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

typedef unsigned char byte;

#define ZERO    (byte)'0'
#define UNO     (byte)'1'

#define ABSXY   999
#define ABSMAX  ABSXY+2      // Intensita' k = 1,2,3
#define DIM     2*(ABSMAX)+1

byte carta[DIM][DIM];
byte foto[DIM][DIM];

#define pos(x)  x+ABSXY+2
#define sop(x)  x-ABSXY-2
//#define cartap(x,y) carta[pos(x)][pos(y)];
//#define fotod(x,y) foto[pos(x)][pos(y)];

int             N, M;


void printfoto( ){
  int i, j;

  for ( j = M-1; j >= 0; j-- ){
    for ( i = 0; i < M; i++ )
      printf( "%c", foto[i][j] );
    printf( "\n" );
  }
}

void printcarta( ){
  int i, j;

  for ( j = DIM-1; j >= 0; j-- ){
    for ( i = 0; i < DIM; i++ )
      printf( "%c", carta[i][j] );
    printf( "\n" );
  }
}


/* INPUT */
void input( ){
  int i, j, x, y, k;
  byte c;

  scanf( "%d %d", &N, &M );
  //assert( M <= N );

  for ( i = 0; i < DIM; i++ )
    for ( j = 0; j < DIM; j++ )
      carta[i][j] = ZERO;
      
  for ( i = N; i > 0; i-- ){
    scanf( "%d", &x );
    scanf( "%d", &y );
    scanf( "%d", &k );
    assert( -ABSXY <= x && x <= ABSXY );
    assert( -ABSXY <= y && y <= ABSXY );
    assert( 1 <= k && k <= 3 );
    if ( k == 1 ) {
      carta[pos(x)][pos(y)] = UNO;
    } else if ( k == 2 ) {
      carta[pos(x)][pos(y)] = UNO;
      carta[pos(x-1)][pos(y)] = UNO;
      carta[pos(x)][pos(y-1)] = UNO;
      carta[pos(x+1)][pos(y)] = UNO;
      carta[pos(x)][pos(y+1)] = UNO;
    } else {
      carta[pos(x)][pos(y)] = UNO;
      carta[pos(x-2)][pos(y)] = UNO;
      carta[pos(x-1)][pos(y)] = UNO;
      carta[pos(x+1)][pos(y)] = UNO;
      carta[pos(x+2)][pos(y)] = UNO;
      carta[pos(x)][pos(y-2)] = UNO;
      carta[pos(x)][pos(y-1)] = UNO;
      carta[pos(x)][pos(y+1)] = UNO;
      carta[pos(x)][pos(y+2)] = UNO;
      carta[pos(x-1)][pos(y-1)] = UNO;
      carta[pos(x-1)][pos(y+1)] = UNO;
      carta[pos(x+1)][pos(y-1)] = UNO;
      carta[pos(x+1)][pos(y+1)] = UNO;
    }
  }

  scanf( "%c", &c ); // \n
  for ( y = M-1; y >= 0; y-- ) {
    for( x = 0;  x < M; x++ ) {
      scanf( "%c", &c );
      assert( c == ZERO || c == UNO );
      foto[x][y] = c;
    }
    scanf( "%c", &c ); //  '\n'
  }

}


/* OUTPUT */
void output( int x, int y ){
  //FILE *fd;

  int xa, xb, xc, xd, ya, yb, yc, yd;

  xa = x;
  ya = y + M - 1;
  xb = x + M - 1;
  yb = y + M - 1;
  xc = x + M - 1;
  yc = y;
  xd = x;
  yd = y;
  
  //fd = fopen("output.txt", "w" );
  //assert( fd != NULL );

  if ( xc < 0 && yc >= 0 ) {
    printf( "A\n" );
    //fclose( fd );
    return;
  }
  if ( xd >= 0 && yd >= 0 ) {
    printf( "B\n" );
    //fclose( fd );
    return;
  }
  if ( xa >= 0 && ya < 0 ) {
    printf( "C\n" );
    //fclose( fd );
    return;
  }
  if ( xb < 0 && yb < 0 ) {
    printf( "D\n" );
    //fclose( fd );
    return;
  }

  if ( xd < 0 && yd >= 0 && xc >= 0 && yc >= 0 ) {
    printf( "AB\n" );
    //fclose( fd );
    return;
  }
  if ( xa < 0 && ya < 0 && xb >= 0 && yb < 0 ) {
    printf( "CD\n" );
    //fclose( fd );
    return;
  }
  if ( xb < 0 && yb >= 0 && xc < 0 && yc < 0 ) {
    printf( "AD\n" );
    //fclose( fd );
    return;
  }
  if ( xa >= 0 && ya >= 0 && xd >= 0 && yd < 0 ) {
    printf( "BC\n" );
    //fclose( fd );
    return;
  }

  printf( "ABCD\n" );
  //fclose( fd );
  return;
}


/* RICERCA */
int findpos( int *x, int*y ){

  int i, ii, j, jj;
  byte res;

  for (i = 0; i < DIM-M; i++)
    for (j = 0; j < DIM-M; j++) {
      res = 1;
      for (ii = 0; res && ii < M; ii++)
	for (jj = 0; res && jj < M; jj++) 
	  if ( foto[ii][jj] != carta[i+ii][j+jj] ) res = 0;
      if (res) {
	*x = sop(i);
	*y = sop(j);
	//printf("%d %d %d %d\n", i, j, *x, *y);
	return 1;
      }	
    }

  return 0;
}


/* MAIN */
int main( int argc, char *argv[] ){
  int x, y;

  input( );
  //printfoto( );
  //printcarta( );

  fprintf( stderr, "ABSXY = %d\n", ABSXY );
  
  if ( findpos( &x, &y ) ){
    output( x, y );
    fprintf( stderr, "(XVAL,YVAL)= (%d, %d)\n", x, y );
  }
  else
    fprintf( stderr, "\nfoto non trovata!\n");

  return 0;
}

/*
** libreria.c
**
** Contiene il codice di supporto per il test della prova
** regionale delle Olimpiadi 2004
**
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "libreria.h"

int main(){
  Tconfig config;
  FILE *f;
  int k,h;
  int xi, rimuovi;
  unsigned long int d, d1;
  unsigned a,b;
  int *strip;
  //int rimuovi[4];
  unsigned nstrip = 0;
  punto p;

  if((f=fopen("input.txt","r"))==NULL){
    fprintf(stderr,"errore 1\n");
    return 0;
  }

  contaPiante(f,&config);
  //printf("%d", config.piante);

  config.aiola = (punto *) malloc(sizeof(punto)*config.piante);
  strip = (int *) malloc(sizeof(int)*config.piante);
  caricaPiante(f,&config);
  
  fclose(f);
  // fine caricamento punti
  

  // al momento la ricerca di piu' punti e' eseguito con la forza bruta
  //

  for(rimuovi=0;rimuovi<config.eliminare;rimuovi++){
    //printf("--\n");
    //visitaAiola(config.aiola,config.piante);

    qsort(config.aiola,config.piante,sizeof(punto),confrontaPuntiX);
    //visitaAiola(config.aiola,config.piante);

    for(k=1,a=0,b=1,d=distanza(config.aiola[a],config.aiola[b]);
	k<config.piante;k++){
      // inizio a fare scorrere la linea che divide il piano
      //
    
      // carico lo strip con tutti i punti la cui proiezione
      // sull'asse delle x e' minore di d

      for(h=k-1,nstrip=0;h>=0;h--){
	if((config.aiola[k].x - config.aiola[h].x) > d)
	  break;
	if(abs(config.aiola[k].y - config.aiola[h].y)>d) continue; 
	strip[nstrip++]=h;
      }
      //printf("distanza corrente %d\n", d);

      for(xi=0;xi<nstrip;xi++){
	if((d1=distanza(config.aiola[strip[xi]],config.aiola[k]))<d){
	  d=d1;
	  b=k;
	  a=strip[xi];
	}
      }
/*       printf("in questo .. punto %d - (%d,%d) (%d,%d)\n",k, */
/* 	     config.aiola[a].x,config.aiola[a].y, */
/* 	     config.aiola[b].x,config.aiola[b].y); */

      
    }

    // I punti da eliminare sono inseriti al termine del vettore
    //

    if((config.aiola[a].y > config.aiola[b].y) 
      ||
      ((config.aiola[a].y == config.aiola[b].y)
	 &&
       (config.aiola[a].x > config.aiola[b].x)
       )
       ){
      p = config.aiola[a];
      config.aiola[a] = config.aiola[config.piante-1];
    }
    else{
      p = config.aiola[b];
      config.aiola[b] = config.aiola[config.piante-1];
    }
 
   config.aiola[config.piante-1] = p;
   config.piante--;
   //visitaAiola(config.aiola,config.piante);
   //printf("elimino (%d,%d)\n", p.x,p.y);
  }
  if((f=fopen("output.txt","w"))==NULL){
    fprintf(stderr,"errore 1\n");
    return 0;
  }
  //config.piante=4;
  //visitaAiola(config.aiola,config.piante);
  
  salva(f,config);
}

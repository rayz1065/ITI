#include <stdlib.h>
#include <stdio.h>

FILE *input,*output;
const int MAXSIZE = 100;
const int MAX = 10000;
//Contiene i pesi dei panini letti dal file di input
int VettoreOriginale[MAXSIZE];
//Contiene i pesi dei panini letti dal file di input ordinati in modo decrescente
int VettoreOrdinato[MAXSIZE];
//Contiene il numero di panini contenuto nel file di input utilizzato
int numpanini;

int Posizioni[MAXSIZE];
int PosizioniSequenzaCrescente[MAXSIZE];
int LunghezzaSequenza;


//Funzione per la lettura dell'input
void ReadInput()
{
 fscanf(input,"%d",&numpanini);
 if(numpanini>MAXSIZE || numpanini <= 0)
 {
			printf("Numero di panini eccessivo, nullo o minore di zero\n");
            fprintf(output,"Numero di panini eccessivo, nullo o minore di zero\n");
			exit(-1);
			}

 printf("Il numero di panini contenuto nel file input considerato � %d \n",numpanini);
 int row;
 int value;
 for(row = 0; row < numpanini; row++)
	{
        fscanf(input,"%d",&value);

 		if(value < 0 || value > MAX)
			{
            
			fprintf(output,"Peso errato nell'input\n");
			printf("Peso errato nell'input\n");
			exit(-1);
			}
         VettoreOriginale[row]=value;
    }
}



/*Questa funzione ordina il vettore dei pesi in modo decrescente e memorizza la posizione di ciascun
  peso prima dell'ordinamento. Posizioni[0] restituir� quindi posizione che aveva nel vettore
  originale il panino con peso massimo che si trova quindi in VettoreOrdinato[0].

*/


void OrdinaVettoreOriginale()
{
int i,temp,massimo,j;
for(i=0;i<numpanini;i++) VettoreOrdinato[i] = VettoreOriginale[i];
for(i=0;i<numpanini;i++) Posizioni[i]=i;

for(i=0;i<numpanini;i++)
       {
       massimo=i;
       for(j=i+1;j<numpanini;j++)
           {
            if(VettoreOrdinato[j]>VettoreOrdinato[massimo]) massimo=j;
            }
       if(massimo!=i)
                  {
                  temp=VettoreOrdinato[massimo];
                  VettoreOrdinato[massimo]=VettoreOrdinato[i];
                  VettoreOrdinato[i]=temp;
                  temp = Posizioni[massimo];
                  Posizioni[massimo]=Posizioni[i];
                  Posizioni[i]=temp;
                  }
       }
for(i=0;i<numpanini;i++) printf("numero %d posizione originale %d\n",VettoreOrdinato[i],Posizioni[i] );
return;
}

/*Questa funzione calcola la massima sottosequenza crescente nel vettore Posizioni
  Qando la funzione viene chiamata il vettore Posizioni contiene la posizione dei vari panini nel menu
  dopo che i panini sono stati ordinati in modo decrescente rispetto al loro peso.
  La massima sottosequenza crescente ottenuta rappresenta, per come agisce il programma, la sequanze pi� lunga di panini
  con pesi decrescenti (o uguali) . */
void LongestIncreasingSubsequence()
{

int i,j;
int max;
int len[MAXSIZE];
// len[i] conterra la lunghezza della sottosequenza crescente pi� lunga
// a partire dall'indice i, e start memorizzer� l'indice in cui la pi� lunga
// sottosequenza crescente inizia.
int start = numpanini-1;

for (int i=numpanini-1; i >= 0; i--) {
      len[i] = 1;
      for (int j=i+1; j < numpanini; j++) {
	         if (Posizioni[j] > Posizioni[i] && len[j] >= len[i])
	            len[i] = len[j] + 1;
      }
      if (len[i] > len[start]) start = i;
    }
PosizioniSequenzaCrescente[0]= Posizioni[start];
int last = Posizioni[start];
int num = len[start] - 1;
int k=1;
for (int i=start+1; num > 0; i++) {
      if (len[i] == num && Posizioni[i] > last) {
	     last = Posizioni[i];
         PosizioniSequenzaCrescente[k]=last;
         k++;
	     num--;
      }
    }

LunghezzaSequenza=k;
printf("coppie posizioni-pesi della pi� lunga sottosequenza crescente\n");
for(i=0;i<LunghezzaSequenza;i++)    printf("%d-%d \n", PosizioniSequenzaCrescente[i], VettoreOriginale[PosizioniSequenzaCrescente[i]] );
return;
}



int main()
{

input=fopen("input.txt","r");
output=fopen("output.txt","w");
 if(input==NULL || output==NULL)
           {
           fprintf(output,"Errore nell'apertura dei file di I/O");
           printf("Errore nell'apertura dei file di I/O");
            return(-1);
            }
//leggo l'input
ReadInput();
//ordino il vettore originale in modo decrescente e pongo in
//Posizione[i] la posizione prima dell'ordinamento del i-esimo elemento del vettore ordinato in modo decrescente
OrdinaVettoreOriginale();
//A questo punto il problema si riduce nella ricerca della lunghezza della pi� lunga sottosequenza crescente del vettore ordinato
LongestIncreasingSubsequence();
/*La funzione LongestIncreasingSubsequence() pone in PosizioniSequenzaCrescente[MAXSIZE] le posizioni in cui
  si trovano i panini che Poldo deve mangiare al fine di mangiare il maggior numero di panini
  Se ci sono panini dello stesso peso essi si troveranno nel vettore PosizioniSequenzaCrescente[MAXSIZE] in celle
  consecutive. Per ciascun eventuale insieme di panini aventi lo stesso peso Poldo pu� mangiarne per� uno solo al
  fine di non violare la regola della sua dieta. Il numero massimo di panini che Poldo pu� qindi mangiare si ottiene
  quindi in questo modo.*/
int massimo;
massimo=1;
int i;
for(i=1;i<LunghezzaSequenza;i++)
    if( VettoreOriginale[PosizioniSequenzaCrescente[i]]!= VettoreOriginale[PosizioniSequenzaCrescente[i-1]])  massimo++;
printf ("Lunghezza massima sequenza = %d \n" , massimo);
fprintf(output,"%d",massimo);

fclose(input);
fclose(output);

 	}


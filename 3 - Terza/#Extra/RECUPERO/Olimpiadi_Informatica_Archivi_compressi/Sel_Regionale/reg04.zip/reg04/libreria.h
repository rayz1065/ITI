/*
** libreria.c
**
** Contiene il codice di supporto per il test della prova
** regionale delle Olimpiadi 2004
**
*/

#ifndef _LIBRERIA_
#define _LIBRERIA_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

typedef struct STpunto{
  int x,y;
} punto;

typedef struct STconfig{
  int piante;
  int eliminare;
  punto *aiola;
} Tconfig;

int contaPiante(FILE *f, Tconfig *c);
void caricaPiante(FILE *f, Tconfig *c);
void visitaAiola(punto aiola[], int n);
int confrontaPuntiY(const void *a, const void *b);
int confrontaPuntiX(const void *a, const void *b);
int confrontaPuntiXY(const void *a, const void *b);
int confrontaPazzo(const void *a, const void *b);
long int distanza(punto a, punto b);
void salva(FILE *f, Tconfig config);
void salvaAiola(FILE *f, Tconfig config);
#endif

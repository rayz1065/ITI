/*

Street Race (IOI 1995)
Copyright (C) 2000 Sebastiano Vigna

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA




Per trovare i punti inevitabili, scriviamo una funzione ricorsiva che
determina tramite esplorazione in profondita` l'insieme dei nodi raggiungibili
da 0 _senza passare per un nodo dato_. Chiaramente un nodo e` inevitabile
se e solo se N-1 non e` raggiungibile a 0 senza passare per il nodo dato.

Infine, un po' di riflessione conduce alla conclusione che un nodo n e` di
spezzamento se e solo se non esiste un nodo che e` raggiungibile da 0 senza
passare da n, ma che e` raggiungibile da n. Vale quindi la pena di scrivere
una funzione di raggiungibilita` leggermente piu` generale, che permette di
risolvere anche il secondo problema.


*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <limits.h>

#define MAXPUNTI 50
#define MAXFRECCE 100

char b[MAXPUNTI]; 	/* Matrice di booleani per accumulare il risultato */
char G[MAXPUNTI][MAXPUNTI]; /* Matrice di adiacenza del grafo */
int N; /* Numero di nodi */

/* Questa funzione esplora in profondita` ricorsivamente il grafo,
	marcando i nodi raggiungibili da n senza passare per e (il nodo
	da evitare). Il vettore v contiene un booleano (visitato/non visitato)
	per nodo

	Si noti che, come accade di frequence, dovendo inizializzare v alla prima
	chiamata conviene dividere in due la funzione--la "vera" funzione
	ricorsiva e` ragg2. Se e e` -1 il calcolo dei nodi raggiungibili viene
	effettuato normalmente (senza ostacoli). */

char v[MAXPUNTI];	/* Nodi visitati */

void ragg2(int n, int e) {
	int i;

	v[n] = 1;

	for(i=0; i<N; i++)
		if (i != e && G[n][i] && !v[i]) ragg2(i, e);
}

void ragg(int n, int e) {
	int i;

	for(i=0; i<N; i++) v[i] = 0;
	ragg2(n, e);
}


int main(int argc, char *argv[]) {

   FILE *f;
	int i, j, t, u;

	f = stdin;
	for(N=0; ;N++) {
		fscanf(f, "%d", &u);
		if (u == -1) break;
		while(u != -2) {
			G[N][u] = 1;
			fscanf(f, "%d", &u);
		}
		fscanf(f, "\n");
	}
	N++; /* L'ultimo nodo non compare nella lista di adiacenza. */

	for(i=1; i<N-1; i++) {
		ragg(0, i);
		if (!v[N-1]) b[i] = 1;
	}

	f = stdout;

	/* Prima contiamo i nodi j con b[j] vero, e poi stampiamo i loro indici. */
	for(i=j=0; i<N; i++) if (b[i]) j++;
	fprintf(f, "%d", j);
	for(i=0; i<N; i++) if (b[i]) fprintf(f, " %d", i);
	fprintf(f, "\n");

	/* Ora scandiamo i nodi inevitabili, e controlliamo se sono
		di spezzamento. */

	for(i=1; i<N-1; i++)
		if (b[i])
			for(j=0; j<N; j++) {
				ragg(0, i);
				t = v[j]; /* = "j e` raggiungibile da 0 senza passare per i". */
				ragg(i, -1);
				if (t && v[j]) {
					b[i] = 0;
					break;
				}
			}

	for(i=j=0; i<N; i++) if (b[i]) j++;
	fprintf(f, "%d", j);
	for(i=0; i<N; i++) if (b[i]) fprintf(f, " %d", i);
	fprintf(f, "\n");

	return 0;
}

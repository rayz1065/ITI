/*

Walls (IOI 2000)
Copyright (C) 2000 Paolo Boldi and Sebastiano Vigna

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA




La soluzione del problema si ottiene analizzando il grafo (non orientato) che
ha per vertici le regioni, e dove due regioni sono adiacenti se un muro le
divide. Per costruire questo grafo occorre un'analisi dell'input un po' piu`
accurata del solito, dato il formato particolare in cui le regioni e le citta`
vengono descritte. In particolare, due regioni sono adiacenti se e solo se due
vertici compaiono consecutivamente, ma in ordine inverso, nella lista che le
delimita.

Una volta costruita la matrice di adiacenza del grafo e la matrice di incidenza
fra citta' e regioni, occorre, per ogni possibile regione d'arrivo, stimare la
distanza di detta regione da tutte quelle da cui potrebbe partire un membro del
club (sono le regioni adiacenti alla sua citta`), sommare e minimizzare. In
pratica ci conviene precomputare le distanze da tutte le regioni incidenti su
una citta` in cui vive qualche membro del club.

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <limits.h>

#define min(a,b) ((a)<(b)?(a):(b))

#define MAXM 200 /* Massimo numero di regioni */
#define MINM 3   /* Minimo numero di regioni */
#define MAXN 250 /* Massimo numero di citta` */
#define MINN 3   /* Minimo numero di citta` */
#define MAXL 30  /* Massimo numero di membri */
#define MINL 1   /* Minimo numero di membri */

unsigned char incidenza[MAXM][MAXN]; /* Incidenza tra regioni e citta` */
unsigned char adiacenza[MAXM][MAXM]; /* Adiacenza tra regioni */
unsigned char muri[MAXN][MAXN]; /* Booleano vero se le due citta` sono, nell'ordine, lungo un muro */
unsigned int disttot[MAXM]; /* Somma degli attraversamenti minima per ogni regione  */
unsigned int distcorr[MAXM]; /* Somma degli attraversamenti minima per la regione in analisi */
unsigned int dist[MAXM][MAXM]; /* Distanza (attraversamenti) tra due regioni */
int casa[MAXL]; /* Dove sta di casa ogni membro */

FILE *F;
int L, M, N;


/* Calcoliamo le distanze da una regione x con una semplice ricerca in
   ampiezza. */

void calcoladistanze(int x) {

	int i, l=1, p=0;
	static int coda[MAXM];

	coda[0] = x;
	for(i=0; i<M; i++) dist[x][i] = INT_MAX;
	dist[x][x] = 0;

	while(p < l) {
		for(i=0; i<M; i++) 
			if (adiacenza[coda[p]][i] && dist[x][i] == INT_MAX) {
				dist[x][i] = dist[x][coda[p]]+1;
				coda[l++] = i;
			}
		p++;
	}
}


int main(int argc, char *argv[]) {
	int k, i, j, t, u, primo, prec;
	FILE *F;

	F = stdin;
	fscanf(F, "%d\n%d\n%d\n", &M, &N, &L);

	for(i=0; i<L; i++) { 
		fscanf(F, "%d", &casa[i]); 
		casa[i]--; 
	}


	/* La fase di input e` un po' rognosa perche' dobbiamo rilevare non solo
		l'adiacenza tra regioni (adiacenza[][]), ma anche l'incidenza delle
		citta` sulle regioni (incidenza[][]) e mantenere il ricordo dell'ordine
		con cui abbiamo incontrato le varie citta` lungo i bordi: piu`
		precisamente, muri[x][y] contiene l'indice aumentato di uno della regione
		lungo il cui bordo abbiamo incontrato x seguito da y, zero se non li
		abbiamo ancora visti in quest'ordine. Se quando incontriamo y seguito da
		x vediamo che muri[x][y] e` nonzero, sappiamo che la regione corrente
		(cioe` quella di indice i) e` adiacente alla regione di indice
		muri[x][y]-1.*/

	for(i=0; i<M; i++) {
		fscanf(F, "%d\n", &t);
		prec = primo = -1;
		for(j=0; j<t; j++) {
			fscanf(F, "%d", &u);
			--u;

			if (prec < 0) primo = u;     
			else {
				incidenza[i][prec] = 1;
				muri[prec][u] = i+1;
				if (muri[u][prec]) adiacenza[i][muri[u][prec]-1] = adiacenza[muri[u][prec]-1][i] = 1; 
			}
      
			prec = u;
		}
		incidenza[i][u] = 1;
		muri[u][primo] = i+1;
		if (muri[primo][u]) adiacenza[i][muri[primo][u]-1] = adiacenza[muri[primo][u]-1][i] = 1; 
	}

	/* Calcoliamo le distanze da ogni area adiacente a una citta` in cui vive un
      membro. */

	for(j=0; j<M; j++) 
		for(i=0; i<L; i++)
			if (incidenza[j][casa[i]]) {
				calcoladistanze(j);
				break;
			}
  

	/* Calcoliamo ora per ogni regione la distanza totale percorsa da tutti i
		membri per raggiungerla. Per ogni membro scegliamo come regione di
		partenza quella piu` vantaggiosa. */

	for(i=0; i<L; i++) {
		for(j=0; j<M; j++) distcorr[j] = INT_MAX;

		for(j=0; j<M; j++) 
			if (incidenza[j][casa[i]]) 
				for(k=0; k<M; k++) distcorr[k] = min(distcorr[k], dist[j][k]);	

		for(j=0; j<M; j++) disttot[j] += distcorr[j];
	}

	/* Non ci resta che minimizzare rispetto a tutte le regioni di arrivo
      possibili. */

	t = INT_MAX;
	for(i=0; i<M; i++) 
		if (disttot[i] < t) {
			t = disttot[i];
			u = i;
		}

	F = stdout;

	fprintf(F, "%d\n%d\n", t, u+1);

	return 0;
}

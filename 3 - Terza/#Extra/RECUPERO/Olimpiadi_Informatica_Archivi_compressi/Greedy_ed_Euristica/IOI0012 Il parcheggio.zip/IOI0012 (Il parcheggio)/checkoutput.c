/*

Car Parking Output Checker (IOI 2000)
Copyright (C) 2000 Paolo Boldi and Sebastiano Vigna

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>
#include <assert.h>

#define MAXN 20000
#define MAXM 50
#define MAXW 50

int N, M, W;
int tipo[2][MAXN];
FILE *in, *out;


int main(int argc, char *argv[]) {
	int i, j, c, s, d, t, N, M, W = 0;

	if (argc < 3) {
		printf("Usage: %s infile outfile\n", argv[0]);
		return 0;
	}

	assert(in = fopen(argv[1], "r"));
	assert(out = fopen(argv[2], "r"));

	fscanf(in, "%d %d %d\n", &N, &M, &W);
	for(i=0; i<N; i++) fscanf(in, "%d", &tipo[0][i]);

	fscanf(out, "%d\n", &t);

	if (t > (N+(W-2))/(W-1)) {
		printf("Numero di turni eccessivo.\n");
		return 0;
	}

	for(i=0; i<t; i++) {
		memcpy(tipo[1], tipo[0], N * sizeof **tipo);
		fscanf(out, "%d", &c);
		for(j=0; j<c; j++) {
			fscanf(out, " %d %d", &s, &d);
			tipo[1][d-1] = tipo[0][s-1];
		}

		memcpy(tipo[0], tipo[1], N * sizeof **tipo);
	}

	for(i=1; i<N; i++) if (tipo[0][i-1] > tipo[0][i]) break;
	printf("Risultato %s.\n", i == N ? "corretto" : "errato");
	return 0;
}

/*

Car Parking Input Generator (IOI 2000)
Copyright (C) 2000 Paolo Boldi and Sebastiano Vigna

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>

#define MAXN 20000
#define MAXM 50
#define MAXW 50

int N, M, W;
int tipo[MAXN];

int main(int argc, char *argv[]) {
	int i, N, M, W = 0;

	if (argc < 3) {
		printf("Usage: %s N M\n", argv[0]);
		return 0;
	}

	N = atoi(argv[1]);
	M = atoi(argv[2]);

	srand(clock());
	while(W < 2) W = rand() % (M+1);

	printf("%d %d %d\n", N, M, W);
	for(i=0; i<N; i++) printf("%d ", (rand() % M) + 1);
	printf("\n");

	return 0;
}

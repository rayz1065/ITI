#!/bin/bash

generatore='./generatore'
solutore='./solutore'
iodir='./InputOutput'

#file di esempio
echo -e "2 4 2\n1 2 2 2\n1 1 1 2\n" > $iodir/input0.txt
echo -e "7 2 3\n1 7\n5 6\n6 7\n2 3\n1 5\n2 4\n3 4\n" > $iodir/input1.txt
#N P M
desc="3 3 1;
5 6 1;
7 9 1;
7 1 9;
9 32 16;
10 10 3;
30 2 9;
40 32 1;
40 1 16;
30 10 1;
60 5 10;
60 10 2;
70 30 1;
90 30 3;
100 30 16;
100 15 8;
100 20 3;
100 30 1;
128 10 15;
128 15 7;
128 20 6;
128 25 3;
128 32 1;"

for((i=1;i<24;i++)); do
    s=$(echo $desc | cut -d";" -f $i)
    n=$(echo $s| cut -d" " -f 1)
    p=$(echo $s| cut -d" " -f 2)
    m=$(echo $s| cut -d" " -f 3)
    $generatore $n $p $m > $iodir/input$(($i+1)).txt
done
 
for (( i = 0 ; i <= 24 ; i++ )); do
    $solutore < $iodir/input$i.txt > $iodir/output$i.txt
done

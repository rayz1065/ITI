/*
Copyright (C) 2004 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include <iostream>
#include <fstream>
#include <string>

//#define DEBUG

using namespace std;

const int N = 129;
const int M = 17;
const int P = 33;
const int MaxPassi = 128*128*32; //rough upper bound

  short int bl[N*P], //Building Label
  ll[M], //Lift Label
  u[N],  // u[k] is the number of packages with label > k
  st[M+P],
  jou[MaxPassi*(M+1)];
int n,m,p,mi;

int main()
{
  int i,j,k,mup;
  bool ftime=true; //before first change of direction?
  memset(bl,0,sizeof(bl));
  memset(ll,-1,sizeof(ll));
  memset(u,0,sizeof(u));
  
  cin>>n>>p>>m;

  for(i=0;i<n;i++)
    {
      for(j=0;j<p;j++) 
	{
	  cin>>bl[i*P+j];
	  bl[i*P+j]--;	
	  for(k=i;k<bl[i*P+j];k++) u[k]++;
	}
      //create u
    }

  mup=n;
  while(!u[--mup]);

#ifdef DEBUG
	  for (int o=0;o<n;o++) cerr<<u[o]<<' ';
	  cerr<<endl;
#endif

	  //se si stampa il percorso bisogna tenere in memoria matrice--> max passi

  int dir=0;// 0 up 1 down
  k=0; //first floor
  int num=1; //1 floor crossed
  jou[M+m]=dir;
  while(1)
    {

#ifdef DEBUG
      cerr<<"k: "<<k<<endl;
#endif
      for (int o=0;o<m;o++) jou[num*M+o]=ll[o]+1;
      jou[(num+1)*M+m]=dir;


      num++;
      i=j=0;


      //merge bl[k*p] and ll into a single sorted array
      while(i<p && j<m)

	if (bl[k*P+i]<ll[j])	    
	  st[i+j]=bl[k*P+i++];	  
	else
	  st[i+j]=ll[j++];
      
      if (i==p)
	memcpy(st+i+j,ll+j,sizeof(short int)*(m-j));
      else
	memcpy(st+i+j,bl+k*P+i,sizeof(short int)*(p-i));
      

      if (!dir) //going up
	{
	  if (u[k]>m) mi=m; else mi=u[k];
	  memcpy(ll,st+p,sizeof(short int)*(m));
	  memcpy(bl+k*P,st,sizeof(short int)*(p));

#ifdef DEBUG
	  for (int o=0;o<m;o++) cerr<<ll[o]+1<<' ';
	  cerr<<endl;
	  for (int o=0;o<p;o++) cerr<<bl[k*P+o]+1<<' ';
	  cerr<<endl;
#endif

	  u[k]-=mi;

	  k++;

	  if ((ftime && k<=mup) || u[k]) continue;

	}
      else
	{
	  memcpy(ll,st,sizeof(short int)*(m));
	  memcpy(bl+k*P,st+m,sizeof(short int)*(p));
	
#ifdef DEBUG	
	  for (int o=0;o<m;o++) cerr<<ll[o]+1<<' ';
	  cerr<<endl;
	  for (int o=0;o<p;o++) cerr<<bl[k*P+o]+1<<' ';
	  cerr<<endl;
#endif

	  k--;

	  if (!k)
	    {
	      if (!u[0]) 
		{
		  for (int o=0;o<m;o++) jou[num*M+o]=ll[o]+1;
		  break;
		}
	    }
	  else
	    {
	      if (u[k-1]) continue;
	    }
	  if (!u[k]) continue;
	}
#ifdef DEBUG	
      cerr<<"Change dir: "<<(1-dir)<<endl<<endl;
#endif
      dir=1-dir;
      ftime=false;
    }

  cout<<num-1<<endl;
  for(k=2;k<=num;k++)
    {
      for (int o=0;o<m;o++) cout<<jou[k*M+o]<<' ';
      cout<<((jou[k*M+m])?('D'):('U'));
      cout<<endl;
    } 


  return 0;
}

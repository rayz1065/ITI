/*
Copyright (C) 2004 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


da utilizzare passando gli output su tr -s " "

*/


#include <iostream>
#include <fstream>
#include <string>
#include <set>
//#define DEBUG

using namespace std;

const int N = 128;
const int M = 16;
const int P = 32;
const int MaxPassi = 128*64; //rough upper bound

  multiset<int> bl[N];
int n,m,p,mi;

int ll[M];

int main()
{
  int i,j,k,a,dir,opt,num;
  char d;
  ifstream in("input.txt");
  ifstream in2("output.txt");
  ifstream in3("out_val.txt");

  in3>>opt;

  in>>n>>p>>m;

  for(i=0;i<n;i++)
    {
      for(j=0;j<p;j++) 
	{
	  in>>a;
	  a--;
	  bl[i].insert(a);
	}
      //create u
    }


  in2>>num;

  //carica tutti 0 (-1) nell'ascensore
      for(j=0;j<m;j++)
	{
	  bl[0].insert(-1);
	}

      k=0;dir=1;
  for(i=1;i<=num;i++)
    {

      for(j=0;j<m;j++)
	{
	  in2>>ll[j];
	  ll[j]--;
	}

      do
	{
	  in2>>d;
	}
      while (d==' ') ;
      if (d=='U')
	dir=1;
      else
	if (d=='D')
	  dir=-1;
	else 
	  {
	    cerr<<"Errore: direzione "<<dir<<"non valida al movimento "<<i<<endl;
	    exit(1);
	  }

      for(j=0;j<m;j++)
	{
	  if (bl[k].find(ll[j])!=bl[k].end())
	    {
	      bl[k].erase( bl[k].find(ll[j]) );
	    }
	  else
	    {
	      cerr<<"Errore: pacco con etichetta "<<ll[j]+1<<" non trovato al piano "<<k+1<<" al movimento "<<i<<endl;
	      exit (1);	      
	    }
	  bl[k+dir].insert(ll[j]);
	}
      
      k+=dir;

      if (k>n) 
      {
	cerr<<"Errore, l'ascensore ha tentato di superare il piano "<<n<<" al movimento "<<i<<endl;
	exit(1);
      }

      if (k<0) 
      {
	cerr<<"Errore, l'ascensore ha tentato di scendere sotto il piano terra al movimento "<<i<<endl;
	exit(1);
      }
      //controlla se i==0 e non ci sono tutti zeri e non va su
    }

   if (k!=0)
      {
	cerr<<"Errore, l'ascensore si e' fermato al piano "<<k+1<<" invece che al primo"<<endl;
	exit(1);
      }

  for(i=0;i<n;i++)
    if (bl[i].count(i)<p)
      {
	cerr<<"Errore, al piano "<<i+1<<" sono presenti solo "<<bl[i].count(i)<<" pacchi con etichetta "<<i+1<<endl;
	exit(1);
      }
  int e=int((double(num-opt)/double(opt))*100.0);
  if (e==0)
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 6"<<endl;
  else if (e<=5)
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 4"<<endl;
  else if (e<=15)
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 3"<<endl;
  else if (e<=30)
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 2"<<endl;
  else if (e<=50)
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 1"<<endl;
  else
    cerr<<"[success] valore trovato: "<<num<<" ottimo: "<<opt<<" punti: 0"<<endl;
}


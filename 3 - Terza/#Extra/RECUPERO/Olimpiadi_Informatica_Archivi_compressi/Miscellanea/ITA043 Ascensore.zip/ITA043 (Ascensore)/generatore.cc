#include <iostream>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

const int N = 128;
const int M = 16;
const int P = 32;

unsigned char mat[N*P];

inline unsigned long int r(unsigned long int lim)
{
  return (unsigned long int)((rand()/double(RAND_MAX))*lim+1);
}


int main(int argN, char* argV[])
{
  if (argN<=3)
    {
      cerr<<argV[0]<<" piani<=128 stanze_per_piano<=32 capacita_ascensore<=16 [seme]"<<endl;
      exit(1);	
    }

  int n=atoi(argV[1]);
  int p=atoi(argV[2]);
  int m=atoi(argV[3]);


  if (argN==4) srand(time(NULL)); 
  else 
    {
      int seed=atoi(argV[4]);
      srand(seed);
    }


  for(int i=0;i<n;i++)
    memset(mat+i*p,i+1,p);

  mat[0]=n; mat[n*p-1]=1;
  int a,tmp;
  for(int i=1;i<n*p-1;i++)
    {
      a=r(n*p-1-i)+i;
      tmp=mat[i];
      mat[i]=mat[a];
      mat[a]=tmp;             
    }
  
  cout<<n<<' '<<p<<' '<<m<<endl;
  for(int i=0;i<n;i++)
    {
      sort(mat+p*i,mat+p*i+p);
      for(int j=0;j<p;j++)
	cout<<int(mat[p*i+j])<<' ';
      cout<<endl;
    }
  return 0;
}

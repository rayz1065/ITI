/*
  Flavio Chierichetti 2004
  Euristica per ASCENSORE - IOI Italiane 2004

  Versione PRELIMINARE 0.2 - Use with caution!!!

  E` un'euristica semplice per ASCENSORE: ha lo scopo di aiutare la
  taratura degli input.
*/
#include <stdio.h>
#include <stdlib.h>
/*#define STDSTREAM*/

typedef struct n {
  char *s;
  struct n *next;
} node;

int N, P, M;

int **Piano, *Ascensore;

int PianoAttuale, Spostamenti, Verso;

int PrimoSbagliato, UltimoSbagliato;

int cmp(const void *a, const void* b);

void primoCarico();
void Step();
void debugPrint();
node* Print();
void contrllaLimiti();


int main(int argc, char *argv[]) {
  FILE *in, *out;
  node *first, *last;
  
  int i, j;

  int end;

#ifdef STDSTREAM
  in = stdin;
  out = stdout;
#else
  in = fopen("input.txt", "r");
  out = fopen("output.txt", "w");
#endif

  if ( in == NULL || out == NULL )
    return 1;

  fscanf(in, " %d %d %d", &N, &P, &M);

  Ascensore = (int*) calloc(M + 1, sizeof(int));
  Ascensore[0] = -1;

  Piano = (int**) calloc(N, sizeof(int*));
  for ( i = 0 ; i < N ; i++ )
    Piano[i] = (int*) calloc(P + M + 1, sizeof(int));

  for ( i = 0 ; i < N ; i++ ) {
    for ( j = 0 ; j < P ; j++ ) {
      fscanf(in, " %d", Piano[i] + j);
      Piano[i][j]--;
    }

    Piano[i][P] = -1;
  }
  
  PianoAttuale = 0;
  Verso = 1;
  Spostamenti = 0;

  primoCarico();

  /*debugPrint();*/

  first = Print();
  last = first;

  while (1) {
    Step();

    if ( PianoAttuale == 0 && PrimoSbagliato == N )
      break;
      
    /*debugPrint();*/

    last->next = Print(out);
    last = last->next;

  }

  /*debugPrint();*/

  fprintf(out, "%d\n", Spostamenti);

  for ( ; first != NULL ; first = first->next )
   fprintf(out, "%s\n", first->s);

  return 0;
}

int cmp(const void *a, const void* b) {
  return *( (int*) a) - *( (int*) b);
}

node* Print() {
  node *n;
  int i, j;

  n = malloc(sizeof(node));

  /* Dovrebbe bastare 4 * M + 2, ma per sicurezza... */
  n->s = malloc( 5 * M + 3 );

  j = 0;
  for ( i = 0 ; Ascensore[i] != -1 ; i++ )
    j += sprintf(n->s + j, "%d ", Ascensore[i] + 1);

  for ( ; i < M ; i++ )
    j += sprintf(n->s + j, "0 ");

  j += sprintf(n->s + j, "%c", Verso == 1 ? 'U' : 'D');

  n->s[j] = '\0';
  
  n->next = NULL;

  return n;
}

void debugPrint() {
  int i, j;
  
  fprintf(stderr, "   ** %d **\n", Spostamenti);
  fprintf(stderr, "PrimoSbagliato: %d\n", PrimoSbagliato);
  fprintf(stderr, "UltimoSbagliato: %d\n", UltimoSbagliato);
  for ( i = 0 ; i < N ; i++ ) {
    fprintf(stderr, "Piano %d: ", i + 1);
    for ( j = 0 ; Piano[i][j] != -1 ; j++ )
      fprintf(stderr, "%d ", Piano[i][j] + 1);
    fprintf(stderr, "\n");
  }
  fprintf(stderr, "Ascensore: ");
  for ( j = 0 ; Ascensore[j] != -1 ; j++ )
    fprintf(stderr, "%d ", Ascensore[j] + 1);
  fprintf(stderr, "\n");
  fprintf(stderr, "Piano: %d\n", PianoAttuale + 1);
  fprintf(stderr, "Prossima Mossa: %s\n", (Verso == 1) ? "SU" : "GIU");
  fprintf(stderr, "\n\n");
}

void controllaLimiti() {
  int i;

  for ( ; PrimoSbagliato < N ; PrimoSbagliato++ ) {
    for ( i = 0 ; i < P ; i++ )
      if ( Piano[PrimoSbagliato][i] != PrimoSbagliato )
	break;

    if ( i < P )
      break;
  }

  for ( ; UltimoSbagliato >= 0 ; UltimoSbagliato-- ) {
    for ( i = 0 ; i < P ; i++ )
      if ( Piano[UltimoSbagliato][i] != UltimoSbagliato )
	break;

    if ( i < P )
      break;
  }
}

void primoCarico() {
  int j, k, n, ok;

  PrimoSbagliato = 0;
  UltimoSbagliato = N - 1;
  controllaLimiti();

  for ( n = 0 ; Piano[PianoAttuale][n] != -1 ; n++ );

  k = 0;
  for ( j = 0 ; j < n && k < M ; j++ )
    if ( (Verso ==  1 && Piano[PianoAttuale][j] > PianoAttuale ) ||
	 (Verso == -1 && Piano[PianoAttuale][j] < PianoAttuale ) ) {
      Ascensore[k] = Piano[PianoAttuale][j];
      k++;
      
      Piano[PianoAttuale][j] = Piano[PianoAttuale][n - 1];
      n--;
      
      j--;
    }

  Ascensore[k] = -1;
  Piano[PianoAttuale][n] = -1;

  qsort(Ascensore, k, sizeof(int), cmp);
}

void Step() {
  int n, i, j, k;

  PianoAttuale += Verso;

  Spostamenti++;

  if ( PrimoSbagliato < N ) {
    if ( PianoAttuale - 1 < PrimoSbagliato )
      Verso = 1;

    if ( PianoAttuale + 1 > UltimoSbagliato )
      Verso = -1;
  } else {
    Verso = -1;
  }

  for ( n = 0 ; Piano[PianoAttuale][n] != -1 ; n++ );
  for ( i = 0 ; Ascensore[i] != -1 ; n++ , i++ )
    Piano[PianoAttuale][n] = Ascensore[i];
  Ascensore[0] = -1;
  Piano[PianoAttuale][n] = -1;

  /*
  for ( j = 0 ; Piano[PianoAttuale][j] != -1 ; j++ )
    printf("%d ", Piano[PianoAttuale][j]);
  printf("\n");
  */
  
  k = 0;

  for ( j = 0 ; j < n && k < M ; j++ )
    if ( (Verso ==  1 && Piano[PianoAttuale][j] > PianoAttuale ) ||
	 (Verso == -1 && Piano[PianoAttuale][j] < PianoAttuale ) ) {
      Ascensore[k] = Piano[PianoAttuale][j];
      k++;
      
      Piano[PianoAttuale][j] = Piano[PianoAttuale][n - 1];
      n--;
      
      j--;
    }

  for ( j = 0 ; n > P ; j++ )
    if ( Piano[PianoAttuale][j] != PianoAttuale ) {
      Ascensore[k] = Piano[PianoAttuale][j];
      k++;
      
      Piano[PianoAttuale][j] = Piano[PianoAttuale][n - 1];
      n--;

      j--;
    }

  Piano[PianoAttuale][n] = -1;
  Ascensore[k] = -1;

  qsort(Ascensore, k, sizeof(int), cmp);

  controllaLimiti();
}

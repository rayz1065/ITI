#!/bin/sh

# I esempio
./generatore 5 5 50 1 121 0 > input/input0.txt
./generatore 5 5 50 1 121 1 > output/output0.txt

# II esempio
#./generatore 5 5 50 0 121 0 > input/inputxx.txt
#./generatore 5 5 50 0 121 1 > output/outputxx.txt

./generatore 4900 4000 64 1 9862 0 > input/input1.txt
./generatore 4900 4000 64 1 9862 1 > output/output1.txt

./generatore 50 100 30 1 131 0 > input/input2.txt
./generatore 50 100 30 1 131 1 > output/output2.txt

./generatore 500 100 43 1 19 0 > input/input3.txt
./generatore 500 100 43 1 19 1 > output/output3.txt

./generatore 500 500 27 1 83 0 > input/input4.txt
./generatore 500 500 27 1 83 1 > output/output4.txt

./generatore 500 1000 33 1 131 0 > input/input5.txt
./generatore 500 1000 33 1 131 1 > output/output5.txt

./generatore 1200 1000 22 1 1111 0 > input/input6.txt
./generatore 1200 1000 22 1 1111 1 > output/output6.txt

./generatore 1200 1500 30 1 371 0 > input/input7.txt
./generatore 1200 1500 30 1 371 1 > output/output7.txt

./generatore 2000 100 31 1 4338 0 > input/input8.txt
./generatore 2000 100 31 1 4338 1 > output/output8.txt

./generatore 200 1500 41 1 9502 0 > input/input9.txt
./generatore 200 1500 41 1 9502 1 > output/output9.txt

./generatore 4900 4000 59 1 8841 0 > input/input10.txt
./generatore 4900 4000 59 1 8841 1 > output/output10.txt

./generatore 100 300 26 1 9716 0 > input/input11.txt
./generatore 100 300 26 1 9716 1 > output/output11.txt

./generatore 300 1500 53 0 9399 0 > input/input12.txt
./generatore 300 1500 53 0 9399 1 > output/output12.txt

./generatore 150 400 58 1 3751 0 > input/input13.txt
./generatore 150 400 58 1 3751 1 > output/output13.txt

./generatore 500 200 32 1 5820 0 > input/input14.txt
./generatore 500 200 32 1 5820 1 > output/output14.txt

./generatore 500 1000 46 1 4592 0 > input/input15.txt
./generatore 500 1000 46 1 4592 1 > output/output15.txt

./generatore 1200 1000 26 1 3078 0 > input/input16.txt
./generatore 1200 1000 26 1 3078 1 > output/output16.txt

./generatore 1200 1500 43 1 1640 0 > input/input17.txt
./generatore 1200 1500 43 1 1640 1 > output/output17.txt

./generatore 2000 100 38 1 6286 0 > input/input18.txt
./generatore 2000 100 38 1 6286 1 > output/output18.txt

./generatore 2000 1500 27 1 2089 0 > input/input19.txt
./generatore 2000 1500 27 1 2089 1 > output/output19.txt


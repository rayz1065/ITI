/* Da chiamare con
   ./generatore-pizza N M seed

   dove N e` il numero di criceti, M quello di macchine e seed e` il seme casuale
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define min(a, b) (( (a) < (b) ) ? (a) : (b))

enum { MaxM = 4000 };

int E[MaxM], P[MaxM];

unsigned int N, M, seed;

int main(int argc, char *argv[]) {
  int i, j, k, e, p, m;

  if ( argc < 4 ||
       sscanf(argv[1], " %d", &N) != 1 ||
       sscanf(argv[2], " %d", &M) != 1 ||
       sscanf(argv[3], " %u", &seed) != 1 )
    return 1;

  srand( seed );
  
  do {

    k = M;
    while ( k > 0 ) {
      e = rand() % ((int) ceil(N / 10.0 + 3.0)) + 1;
      
      p = rand() % (int) ceil(5.0 * N / M + 2.0) + 1;

      /* Riduco ai minimi termini (e / p) */

      j = 1;
      for ( i = 2 ; i <= min(e, p) ; i++ ) {
	while ( (e % j == 0) && (p % j == 0) )
	  j *= i;

	j /= i;
      }

      e /= j;
      p /= j;

      for ( i = 1 ; (rand() % 100 >= 50) && (k > 0) ; i++ )
	if ( rand() % 100 >= 20 ) {
	  k--;

	  E[k] = e * i;
	  P[k] = p * i;
	  
	  /*
	  fprintf(stderr, "%d, (%d, %d)\n", i, e, p);
	  */
	}
    }

    i = 0;
    for ( k = 0 ; k < M ; k++ )
      i += P[k];

    if ( i >= N )
      break;
  } while (1);

  printf("%d %d\n", N, M);
  for ( i = 0 ; i < M ; i++ )
    printf("%d %d\n", E[i] % 1000 + 1, P[i] % 1000 + 1);

  return 0;
}

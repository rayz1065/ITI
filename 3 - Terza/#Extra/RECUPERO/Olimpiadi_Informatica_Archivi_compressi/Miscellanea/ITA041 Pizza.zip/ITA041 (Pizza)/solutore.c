/*
  Flavio Chierichetti 2004
  Soluzione per ``PIZZA GREEDY'' o ``PIZZA SEMPLICE'' - IOI Italiane 2004

  Versione PRELIMINARE - Use with caution!!!
*/
#include <stdio.h>
#define STDSTREAM

typedef struct {
  int E, P;
} automobile;

int cmp(const void *a, const void *b);

int N, M;
automobile* Auto;

int main(int argc, char *argv[]) {
  FILE *in, *out;
  int i;
  int totE, totP;

#ifdef STDSTREAM
  in = stdin;
  out = stdout;
#else
  in = fopen("input.txt", "r");
  out = fopen("output.txt", "w");
#endif
  
  if ( in == NULL || out == NULL )
    return 1;
  
  /* -- Lettura input -- */

  if ( fscanf(in, " %d %d", &N, &M) != 2 )
    return 2;
  
  Auto = (automobile*) calloc(M, sizeof(automobile));

  for ( i = 0 ; i < M ; i++ )
    if ( fscanf(in, " %d %d", &(Auto[i].E), &(Auto[i].P)) != 2 )
      return 3 + i;
  
  qsort(Auto, M, sizeof(automobile), cmp);

  totP = totE = 0;
  for ( i = 0 ; totP < N && i < M ; i++ )
    if ( totP + Auto[i].P <= N ) {
      totE += Auto[i].P * Auto[i].E;
      totP += Auto[i].P;
    } else {
      totE += (N - totP) * Auto[i].E;
      totP = N;
    }

  if ( totP == N )
    fprintf(out, "%d\n", totE);
  else
    fprintf(out, "Non e` possibile portare tutti i criceti a destinazione.\n", totE);
    

  return 0;
}


int cmp(const void *a, const void *b) {
  automobile A, B;

  A = *((automobile*) a);
  B = *((automobile*) b);

  return A.E - B.E;
}

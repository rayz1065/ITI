#!/bin/bash

generatore='./generatore'
solutore='./solutore'
iodir='./InputOutput'

n=0

echo -e "2 4\n2 1\n2 1\n1 5\n1 4\n" > $iodir/input$n.txt

n=$((n + 1))

for (( i = 1 ; i <= 8 ; i++ )); do
    $generatore $((i * 500)) $((i * 250)) $((3 * i)) > $iodir/input$n.txt
    n=$((n + 1))

    $generatore $((i * 250)) $((i * 500)) $((3 * i + 1)) > $iodir/input$n.txt
    n=$((n + 1))

    $generatore $((i * 500)) $((i * 500)) $((3 * i + 2)) > $iodir/input$n.txt
    n=$((n + 1))
done

for (( i = 0 ; i < n ; i++ )); do
    $solutore < $iodir/input$i.txt > $iodir/output$i.txt
done

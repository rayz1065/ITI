#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

const int Nmax = 1000;
const int Mmax = 50000;

//tutti le possibili permutazione di tre colori distinti.
int isoCol[6][3] =
  { {0, 1, 2}, {0, 2, 1}, {1, 0, 2}, {1, 2, 0}, {2, 0, 1}, {2, 1, 0} };
int sol[Nmax], col[Nmax], elfo[Nmax];
int adj[Nmax][Nmax];
int isoVal[6] = { 0, 0, 0, 0, 0, 0 };
int  minH, bestIso, minHTmp;
int N, M;
ifstream fin;
ofstream fout;

//salva la soluzione
void
saveSol ()
{
  //bestIso contiene l'indice dell'isomorfismo che ha la minHima
  //distanza di Hamming dalla soluzione dell'elfo
  for (int i = 0; i < N; i++)
    sol[i] = isoCol[bestIso][col[i]];
}


//legge il file di input
void
readFile ()
{
  fin >> N >> M;
  int i, j, a, b;
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      adj[i][j] = 0;

  for (i = 0; i < M; i++)
    {
      fin >> a >> b;
      a--;b--;
      adj[a][b] = adj[b][a] = 1;
    }
  for (i = 0; i < N; i++)
    {
      fin >> elfo[i];
      elfo[i]--;
    }

}

//esplora lo spazio delle possibili colorazioni
void
color (int i)
{
  int k, j;
  if (i == N)
    {
      if (minHTmp < minH)
	{
	  minH = minHTmp;
	  saveSol ();
	}
      return;
    }

  for (j = 0; j < 3; j++)
    {
      for (k = 0; k < i; k++)
	if (adj[k][i] && col[k] == j)
	  break;
      if (k < i)
	continue;


      minHTmp = INT_MAX;
      //calcola le distanze di Hamming tra la soluzione dell'elfo e
      //TUTTI I 6 ISOMORFISMI della soluzione parziale corrente
      for (k = 0; k < 6; k++)
	{
	  if (isoCol[k][j] != elfo[i])
	    isoVal[k]++;
	  //minimizza.
	  if (isoVal[k] < minHTmp)
	    {
	      minHTmp = isoVal[k];
	      bestIso = k;
	    }

	}
      //se tutto va bene, colora il nodo!!
      col[i] = j;

       color (i + 1);

      //rimette tutto a posto
      for (k = 0; k < 6; k++)
	{
	  if (isoCol[k][j] != elfo[i])
	    isoVal[k]--;
	}

    }
}

void
writeSol ()
{
  if (  minH != INT_MAX )
    {
      fout << minH << endl;
      for (int i = 0; i < N; i++)
	fout << ++sol[i] << ' ';
      fout << endl;
    }
  else fout<<-1<<endl;
}

int
main ()
{
  fin.open ("input.txt");
  fout.open ("output.txt");

  readFile ();

  minH = INT_MAX;

  //fissa il colore iniziale, elimina cos� 4 deglii isomorfismi
  col[0] = 0;
  for (int k = 0; k < 6; k++)
	{
	  if (isoCol[k][0] !=elfo[0])
	    isoVal[k]++;
	}
  color(1);
  writeSol ();
  return 0;

  fout.close ();
}

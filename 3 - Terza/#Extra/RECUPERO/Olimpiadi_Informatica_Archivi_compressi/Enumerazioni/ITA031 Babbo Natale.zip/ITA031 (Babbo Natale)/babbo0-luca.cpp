#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

const int Nmax = 1000;
const int Mmax = 50000;

//trova tutte le possibili colorazioni.


int sol[Nmax], col[Nmax], elfo[Nmax];
int adj[Nmax][Nmax];
int minH;
int N, M;
ifstream fin;
ofstream fout;

//salva la soluzione
void
saveSol ()
{
  for (int i = 0; i < N; i++)
    sol[i] = col[i];
}


//legge il file di input
void
readFile ()
{
  fin >> N >> M;
  int i, j, a, b;
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      adj[i][j] = 0;

  for (i = 0; i < M; i++)
    {
      fin >> a >> b;
      --a;--b;
      adj[a][b] = adj[b][a] = 1;
    }
  for (i = 0; i < N; i++)
    {
      fin >> elfo[i];
      elfo[i]--;
    }

}

//esplora lo spazio delle possibili colorazioni
void color (int i)
{
  int k, j;
  if (i == N)
    {
      int minHTmp=0;
      for (i = 0; i < N; i++)
	if (col[i]!= elfo[i]) minHTmp++;

      if (minHTmp < minH)
	{
	  saveSol ();
	  minH=minHTmp;
	}
      return;
    }

  for (j = 0; j < 3; j++)
    {
      for (k = 0; k < i; k++)
	if (adj[k][i] && col[k] == j) break;
      if (k < i)
	continue;


      //se tutto va bene, colora il nodo!!
      col[i] = j;
      color (i + 1);
    }
}

void
writeSol ()
{
  if (  minH != INT_MAX )
    {
      fout << minH << endl;
      for (int i = 0; i < N; i++)
	fout << ++sol[i] << ' ';
      fout << endl;
    }
  else fout<<-1<<endl;
}

int
main ()
{
  fin.open ("input.txt");
  fout.open ("output.txt");

  readFile ();

  minH = INT_MAX;

  color (0);

  writeSol ();
  return 0;

  fout.close ();
}

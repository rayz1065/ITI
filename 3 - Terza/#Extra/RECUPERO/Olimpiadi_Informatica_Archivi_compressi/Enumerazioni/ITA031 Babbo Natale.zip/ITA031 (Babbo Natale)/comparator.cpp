#include <fstream>
#include <iostream>
#include <cmath>
using namespace std;

const int Nmax=1000;

int elfo[Nmax], g[Nmax];

void ex( char *msg, float res ) {
   if (msg) cerr << "[\x1b[1m\x1b[31m" << msg << "\x1b[m] ";
   cout << res << endl;
   exit(0);
}

int main(int argc, char* argv[])
{
  ifstream fin(argv[1]);
  ifstream rout(argv[2]);
  ifstream gout(argv[3]);

  int N,M,gval,rval;

  if (argc!=4) 
    {
      cerr<<"correttore input output di riferimento output dato"<<endl;
      return 0;
    }

  fin >> N >> M;
  rout>>rval;
  gout>>gval;

  if (rval==-1 && gval==-1) ex( NULL, 1 );
  if (rval==-1 && gval!=-1) ex( "Attenzione! Non � possibile accontentare tutti i bambini!", 0 );
  if (rval!=-1 && gval==-1) ex( "Attenzione! � possibile accontentare tutti i bambini!", 0 );
  if (rval<gval) ex( "Il numero di regali da cambiare � maggiore dello stretto necessario", 0 );
  if (rval>gval) ex( "Il numero di regali da cambiare � minore del minimo possibile", 0 );

  int i, j, a, b;

  for (i = 0; i < N; i++) gout >> g[i];

  for (i = 0; i < M; i++) 
    { fin >> a >> b; 
    if (g[--a]==g[--b]) ex( "La colorazione data non � corretta", 0 );
   };

  for (i = 0; i < N; i++) fin >> elfo[i];
   
  int change=0;
  for (i = 0; i < N; i++)
    {
      if (g[i]!=elfo[i]) change++;
    }

  if (gval!=change) ex( "Il numero di cambiamenti effettuati non corrisponde", 0 );
  //attenzione da specificare che punteggio assegnare!!

  if ( gval == rval ) ex( NULL, 1 );
  //ex( NULL, exp(1.0-double(gval+1)/double(rval+1)) );
  

  return 0;
}

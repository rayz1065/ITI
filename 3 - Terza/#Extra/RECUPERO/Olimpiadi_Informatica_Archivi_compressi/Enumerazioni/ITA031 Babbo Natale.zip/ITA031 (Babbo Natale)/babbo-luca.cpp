/*

Babbo Natale (selezioni nazionali 2003)

Copyright (C) 2003 Luca Foschini

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

const int Nmax = 400;
const int Mmax = 5000;

/*
Chiamiamo G il grafo che ha per nodi i bambini e che ha una arco dal
bambino x al bambino y se e solo i due bambini x e y sono amici.

Associamo a ogni nodo un tipo di regalo. I tipi sono in tutto 3 (che
chiameremo 0,1,2) e devono essere assegnati in modo che se due bambini
x e y sono amici devono avere un regalo di tipo diverso (si dice che
il grafo deve essere colorato con al pi� tre colori)
Un grafo che non pu� essere colorato con 3 colori si dice che non �
3-colorabile.

Diciamo che due colorazioni C1 e C2 (intese come sequenze c_1 c_2 c_3
.. c_n dei colori da assegnare ai nodi 1,2,3, ... , n) distano K se il
numero di nodi corrispondenti che hanno colori diversi � K.

Il problema richiede quindi di trovare, se esiste, la colorazione di G
che abbia distanza minima dalla colorazione iniziale assegnata dall'elfo.
Se tale colorazione non esiste il programma deve restituire -1

Il problema di trovare una n-colorazione di un grafo � risolvibile
solo con ricerca esaustiva (si provano tutte le possibili
combinazioni) tuttavia, � possibile diminuire di molto lo spazio di
ricerca (tagliando rami dell'albero di ricerca) con alcune piccole
considerazioni:

1) Una volta trovata una colorazione del grafo, ne esistono altre 5
   (colorazioni isomorfe) che "equivalgono" quella trovata a meno dei
   nomi dei colori, ad esempio:

se 0,0,0,1,1,2 � una colorazione di un grafo di 6 nodi, allora anche 
1,1,1,2,2,0  lo � di sicuro in quanto pu� essere derivata dalla
precedente cambiano il nome dei colori (in particolare chiamando lo 0
1, l'1 2 e il 2 0)

Pu� quindi essere utile (e lo �) trovare una colorazione e calcolare
la distanza dalla colorazione dell'elfo della colorazione trovata e di
tutte quelle ad essa isomorfe. Sar� poi necessario in seguito evitare
di ritrovare le colorazioni gi� considerate.
(Tecnica del taglio delle simmetrie)


2) Se una colorazione parziale dei primi k nodi  c_1,c_2,...,c_k (con
   k<n) ha distanza dalla colorazione dell'elfo maggiore od uguale alla
   distanza minima trovata tra una colorazione completa (tutti gli n
   nodi) e quella dell'elfo, non ha senso tentare di estendere la
   colorazione parziale perch� comuque si arriverebbe a una distanza
   dalla colorazione dell'elfo al pi� uguale (mai minore) alla minima
   gi� trovata.
   (Tecnica del Branch and Bound)

*/


//tutti le possibili permutazione di tre colori distinti.
int isoCol[6][3] =
  { {0, 1, 2}, {0, 2, 1}, {1, 0, 2}, {1, 2, 0}, {2, 0, 1}, {2, 1, 0} };

//sol contiene la soluzione, col la colorazione corrente, elfo la colorazione dell'elfo
int sol[Nmax], col[Nmax], elfo[Nmax];

//la lista di adiacenza del grafo
int adj[Nmax][Nmax];

//contiene la distanza tra ognuno dei sei isomorfismi di una
//colorazione e la colorazione dell'elfo.
int isoVal[6] = { 0, 0, 0, 0, 0, 0 };
int firstDiff, lastCol, minH, bestIso, minHTmp;
int N, M;
ifstream fin;
ofstream fout;

//salva la soluzione
void
saveSol ()
{
  //bestIso contiene l'indice dell'isomorfismo che ha la minima
  //distanza dalla soluzione dell'elfo
  for (int i = 0; i < N; i++)
    sol[i] = isoCol[bestIso][col[i]];
}


//legge il file di input
void
readFile ()
{
  fin >> N >> M;
  int i, j, a, b;
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      adj[i][j] = 0;

  for (i = 0; i < M; i++)
    {
      fin >> a >> b;
      a--;b--;
      adj[a][b] = adj[b][a] = 1;
    }
  for (i = 0; i < N; i++)
    {
      fin >> elfo[i];
      elfo[i]--;
    }

}

//esplora lo spazio delle possibili colorazioni
void
color (int i)
{
  int k, j;
  //se sono stati colorati tutti i nodi...
  if (i == N)
    {
      //vediamo quanto dista la colorazione attuale da quella ottima
      //fino ad ora trovata.
      minH = minHTmp;
      saveSol ();
      return;
    }

  //per ognuno dei tre colori.
  for (j = 0; j < 3; j++)
    {

      //controlla se il colore j non � gi� stato assegnato a nodi
      //adiacenti al nodo i
      for (k = 0; k < i; k++)
	if (adj[k][i] && col[k] == j)
	  break;

      //prova con il colore successivo se la ricerca precedente �
      //andata a buon fine
      if (k < i)
	continue;

      //Black Magic
      //elimina l'ultimo isomorfismo (simmetrico)

      if (i == firstDiff && j == lastCol)
	continue;
      if (j!=0 && i < firstDiff)
	firstDiff = i;


      minHTmp = INT_MAX;
      //calcola le distanze tra la soluzione dell'elfo e
      //TUTTI I 6 ISOMORFISMI della soluzione parziale corrente
      for (k = 0; k < 6; k++)
	{
	  if (isoCol[k][j] != elfo[i])
	    isoVal[k]++;
	  //minimizza.
	  if (isoVal[k] < minHTmp)
	    {
	      minHTmp = isoVal[k];
	      bestIso = k;
	    }

	}
      //se tutto va bene, colora il nodo!!
      col[i] = j;

      //Branch & Bound
      if (minHTmp < minH)
	color (i + 1);

      //rimette tutto a posto
      for (k = 0; k < 6; k++)
	{
	  if (isoCol[k][j] != elfo[i])
	    isoVal[k]--;
	}

    }
}

void
writeSol ()
{
  if (  minH != INT_MAX )
    {
      fout << minH << endl;
      for (int i = 0; i < N; i++)
	fout << ++sol[i] << ' ';
      fout << endl;
    }
  else fout<<-1<<endl;
}

int
main ()
{
  fin.open ("input.txt");
  fout.open ("output.txt");

  readFile ();

  firstDiff = N + 1;
  minH = INT_MAX;

  //fissa il colore iniziale, elimina cos� 4 deglii isomorfismi
  col[0] = 0; lastCol=2; //(elfo[0]==2)?1:2;

  for (int k = 0; k < 6; k++)
	{
	  if (isoCol[k][0] !=elfo[0])
	    isoVal[k]++;
	}
  color(1);
  writeSol ();
  return 0;

  fout.close ();
}

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <assert.h>


#define MAXN        1000
#define MAXM        1000

int N, M;

int a[ MAXN ][ MAXN ];
int elfo[ MAXN ];
int best[ MAXN ];
int corr[ MAXN ];
int diff = INT_MAX;

void colora( int v, int corrdiff ) {
   int i, j;
   if ( v == N ) {
      assert ( corrdiff < diff );
      memcpy( best, corr, sizeof( int ) * N );
      diff = corrdiff;
      return;
   }
   for ( i = 0; i < 3; i++ ) {
      if ( i && corrdiff + 1 >= diff ) return; // Taglio!
      // Il colore elfo[ v ]+i e' possibile?
      for ( j = 0; j < v; j++ )
	 if ( a[ j ][ v ] && corr[ j ] == ( elfo[ v ] + i ) % 3 ) break;
      if ( j < v ) continue;
      // Prova questa colorazione
      corr[ v ] = ( elfo[ v ] + i ) % 3;
      if ( i ) colora( v+1, corrdiff + 1 );
      else colora( v+1, corrdiff );
   }
}


int main() {
   int i, x, y;
   FILE *fin, *fout;

   // Lettura input
   fin = stdin;
   fscanf( fin, "%d %d", &N, &M );
   for ( i = 0; i < M; i++ ) {
      fscanf( fin, "%d %d", &x, &y ); x--; y--;
      a[ x ][ y ] = a[ y ][ x ] = 1;
   }
   for ( i = 0; i < N; i++ ) {
      fscanf( fin, "%d", &elfo[ i ] );
      elfo[ i ]--;
   }
   fclose( fin );

   // Prova colorazione
   colora( 0, 0 );

   // Output
   fout = stdout;
   if ( diff == INT_MAX ) {
      fprintf( fout, "%d\n", -1 );
   } else {
      fprintf( fout, "%d\n", diff );
      for ( i = 0; i < N; i++ ) fprintf( fout, "%d ", best[ i ]+1 );
      fprintf( fout, "\n" );
   }
   fclose( fout );

   return 0;

}

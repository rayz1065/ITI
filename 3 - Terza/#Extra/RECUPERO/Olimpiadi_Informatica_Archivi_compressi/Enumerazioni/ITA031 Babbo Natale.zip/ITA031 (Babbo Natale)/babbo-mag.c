#include <stdio.h>
#include <stdlib.h>

#define MAXV 305
#define MAXE 4005

typedef struct ND
{
  struct ND *n;
  int a;
  int rmc;
} NODO;

typedef struct
{
  NODO *n;
  int ori;
  int new;
  int g[4];
  int grado;
  int rmc;
} INIZIO;

typedef struct
{
  int a, b;
} EDGE;

FILE *fi, *fo;
int V, E;
INIZIO l[MAXV];
int nrmc;
int rmc[MAXV];

int
conf(const void *a, const void *b)
{
  int c = *((int*)a), d = *((int*)b);
  if (c == -1)
    return 1;
  if (d == -1)
    return -1;
  return l[d].rmc - l[c].rmc;
}

int
trova_rmc(int i, int k)
{
  NODO *n;
  for (n = l[i].n; n; n = n->n)
    if (l[n->a].new == k)
      return 1;
  return 0;
}

void
aggiusta(int i)
{
  NODO *n;
  int k;
  for (n = l[i].n; n; n = n->n)
    {
      l[n->a].g[l[i].new] = 0;
      if (!trova_rmc(n->a, l[i].ori))
	l[n->a].g[l[i].ori] = 1;
      else 
	l[n->a].g[l[i].ori] = 0;
      if (l[n->a].new == l[i].ori)
	{
	  l[n->a].rmc--;
	  if (l[n->a].rmc == 0)
	    {
	      for (k = 0; k < nrmc; k++)
		if (rmc[k] == n->a)
		  {
		    rmc[k] = -1;
		    break;
		  }
	    }
	}
    }
}

void
calcola_rmc_e_gl(void)
{
  int i;
  NODO *n;
  nrmc = 0;
  for (i = 0; i < V; i++)
    {	
      l[i].g[1] = l[i].g[2] = l[i].g[3] = 1;
      for (n = l[i].n; n; n = n->n)
	{
	  l[i].g[l[n->a].ori] = 0;
	  if (l[i].ori == l[n->a].ori)
	    {
	      if (l[i].rmc == 0)
		rmc[nrmc++] = i;
	      l[i].rmc++;
	    } 
	}
    }
}

void
provaci_una_volta(void)
{
  int i = 0, nrmcold;
  nrmcold = nrmc + 1;
  qsort(rmc, nrmc, sizeof(int), conf);
  for (; rmc[nrmc - 1] == -1; nrmc--);
  while (nrmc != 0 && nrmc != nrmcold)
    {
      nrmcold = nrmc;
      if (l[rmc[i]].rmc == 0)
	rmc[i] = -1;
      if (rmc[i] == -1)
	continue;
      
      if (l[rmc[i]].g[1] == 1)
	l[rmc[i]].new = 1;
      else if (l[rmc[i]].g[2] == 1)
	l[rmc[i]].new = 2;
      else if (l[rmc[i]].g[3] == 1)
	l[rmc[i]].new = 3;
      else
	continue;
      l[rmc[i]].rmc = 0;
      aggiusta(rmc[i]);	
      rmc[i] = -1;
      qsort(rmc, nrmc, sizeof(int), conf);
      for (; rmc[nrmc - 1] == -1; nrmc--);
    }
}

void
provaci_ancora_sam(void)
{
  int i;
  NODO *n;
  qsort(rmc, nrmc, sizeof(int), conf);
  for (; rmc[nrmc - 1] == -1; nrmc--);
  for (i = 0; i < nrmc; i++)
    {
      if (l[rmc[i]].rmc)
	for (n = l[rmc[i]].n; n; n = n->n)
	  {
	    if (l[n->a].new != 1 && l[n->a].g[1] && !trova_rmc(rmc[i], 1))
	      {
		int old = l[n->a].new;
		l[n->a].new = 1;
		aggiusta(n->a);
		l[rmc[i]].new = old;
		aggiusta(rmc[i]);
		nrmc--;
		break;
	      }
	    else if (l[n->a].new != 2 && l[n->a].g[2] && !trova_rmc(rmc[i], 2))
	      {
		int old = l[n->a].new;
		l[n->a].new = 2;
		aggiusta(n->a);
		l[rmc[i]].new = old;
		aggiusta(rmc[i]);
		nrmc--;
		break;
	      }
	    else if (l[n->a].new != 3 && l[n->a].g[3] && !trova_rmc(rmc[i], 3))
	      {
		int old = l[n->a].new;
		l[n->a].new = 3;
		aggiusta(n->a);
		l[rmc[i]].new = old;
		aggiusta(rmc[i]);
		nrmc--;
		break;
	      }
	  }
    }
}

int
main(void)
{
  int i, nc = 0;
  fi = fopen("input.txt", "rt");
  fo = fopen("output.txt", "wt");
  fscanf(fi, "%d %d", &V, &E);
  for (i = 0; i < E; i++)
    {
      int v1, v2;
      NODO *n;
      fscanf(fi, "%d %d", &v1, &v2);
      v1--;
      v2--;
      l[v1].grado++;
      l[v2].grado++;
      n = l[v1].n;
      l[v1].n = calloc(1, sizeof(NODO));
      l[v1].n->n = n;
      l[v1].n->a = v2;
      n = l[v2].n;
      l[v2].n = calloc(1, sizeof(NODO));
      l[v2].n->n = n;
      l[v2].n->a = v1;
    }
  for (i = 0; i < V; i++)
    {
      fscanf(fi, "%d", &l[i].ori);
      l[i].new = l[i].ori;
    }
  calcola_rmc_e_gl();

  provaci_una_volta();
  if (nrmc != 0)
    {
      provaci_ancora_sam();
      if (nrmc)
	{
	  fprintf(fo, "-1\n");
	  return 0;
	}
    }
  for (i = 0; i < V; i++)
    if (l[i].new != l[i].ori)
      nc++;
  fprintf(fo, "%d\n", nc);
  for (i = 0; i < V; i++)
    fprintf(fo, "%d ", l[i].new);
  fprintf(fo, "\n");
  fclose(fi);
  fclose(fo);
  return 0;
}

//generarore di file di input per Babbo Natale

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <map>

using namespace std;

const int Nmax=1000;
int v[Nmax];
int adj[Nmax][Nmax];
int visited[Nmax];

int r(int a)
{
  return int(double(a)*(double(rand())/double(RAND_MAX)))+1;
}

int main(int argc, char* argv[])
{
  srand(time(NULL));
  if (argc!=5)
    {
      //genera un grafo con al piu' N_nodi nodi connesso.
      //Vi e' un arco da i a j con probabilita' al piu' uguale a Pcon
      //3-col puo' essere 1 o 0. Se e' uguale a 1 il programma controlla che il grafo generato sia 3-colorabile
      //altrimenti no.
      //right puo' essere 1 o 0. Se e' uguale a 1 il programma fornisce una colorazione iniziale corretta
      cerr<<"errore: generatore N_nodi Pcon 3-col, right"<<endl;
      return 1;
    }
 
  int N=atoi(argv[1]);
  double Pcon=atof(argv[2]);
  int col3=atoi(argv[3]);
  int right=atoi(argv[4]);
  
  
  if (N>Nmax || Pcon>1.0 || (col3!=0 && col3!=1) || (right!=0 && right!=1))
    {
      cerr<<"errore: N_Nodi<"<<Nmax<<" Pcon < 1.0 , col3,right in {0,1}"<<endl;
      return 1;
    }

  int i,j;


  for(i=0;i<N;i++)
    v[i]=r(3);

  for(i=0;i<N;i++)  for(j=0;j<N;j++) adj[i][j]=0;
   
  double arc=0;
  long int attemp=0;
  while(((arc/(double(N*(N-1)/2)))<Pcon) && (attemp<1000000))
    {
      for(i=0;i<N;i++)
	{
	  attemp++;
	  j=r(N)-1;
	  if (i!=j && !adj[i][j] && (v[i]!=v[j] || !col3))
	    {
	      adj[i][j]=adj[j][i]=1;
	      ++arc;
	    }
	}
    }

  int flag =1,node=1;
  visited[0]=1;
  while (flag)
    {
      flag=0;
      for(i=0;i<N;i++)
	if (visited[i]){
	  for(j=0;j<N;j++)
	    if  (adj[i][j] && !visited[j]) {flag=1; visited[j]=++node;} 
	}
    }


  int M=0;

  for(i=0;i<N;i++)
    for(j=i+1;j<N;j++)
      if (adj[i][j] && visited[i]) M++;

  cout<<node<<' '<<M<<endl;

  for(i=0;i<N;i++)
    for(j=i+1;j<N;j++)
      if (adj[i][j] && visited[i]) cout<<visited[i]<<' '<<visited[j]<<endl;
  
    for(i=1;i<=node;i++) 
      for (j=0;j<N;j++)
	if (visited[j]==i) cout<<((right)?v[j]:r(3))<<' ';
  cout<<endl;


  return 0;
}
